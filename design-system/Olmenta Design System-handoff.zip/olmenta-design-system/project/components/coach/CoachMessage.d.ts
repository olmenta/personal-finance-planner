import * as React from "react";

export interface CoachMessageProps {
  /** coach = left sparkle bubble · user = right violet bubble */
  role?: "coach" | "user";
  children?: React.ReactNode;
  style?: React.CSSProperties;
}

/**
 * A single Coach chat bubble. Coach speaks from the left behind a sparkle
 * avatar; the user replies from the right in violet. Coach bubbles may embed
 * rich content (mini cards, budget bars, lists).
 */
export declare function CoachMessage(props: CoachMessageProps): JSX.Element;
