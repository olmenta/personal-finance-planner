import * as React from "react";

/**
 * @startingPoint section="Coach" subtitle="Dark AI insight capsule" viewport="700x80"
 */
export interface CoachCapsuleProps {
  /** Short coach message */
  message?: React.ReactNode;
  /** Trailing call-to-action label; omit to hide */
  cta?: React.ReactNode;
  onClick?: () => void;
  /** Sparkle accent color */
  accent?: "mint" | "violet";
  style?: React.CSSProperties;
}

/**
 * Signature dark coach banner with a sparkle glyph and a CTA. Use it to
 * surface a single proactive AI insight (home screen, dashboard). It is the
 * only dark capsule in the system — keep it rare and high-value.
 */
export declare function CoachCapsule(props: CoachCapsuleProps): JSX.Element;
