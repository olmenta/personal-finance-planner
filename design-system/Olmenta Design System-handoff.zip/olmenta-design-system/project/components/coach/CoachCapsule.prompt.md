Olmenta's signature dark AI banner — use to surface one proactive coach insight on the home screen or dashboard.

```jsx
<CoachCapsule message="You're spending 18% more on dining this month" cta="See why" onClick={openCoach} />
```

It is the only dark capsule in the system; keep it rare and high-value. `accent="mint"` (default) tints the sparkle; pass `cta={null}` for a non-interactive note.
