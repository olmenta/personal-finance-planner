import * as React from "react";
import type { IconName } from "../core/Icon";

export type Suggestion = string | { label: string; icon?: IconName };

export interface CoachSuggestionProps {
  /** Prompt chips — strings or {label, icon} */
  suggestions: Suggestion[];
  onPick?: (label: string) => void;
  style?: React.CSSProperties;
}

/**
 * A wrapping row of tappable prompt chips that seed the coach conversation
 * ("Where can I cut back?", "Am I on track for Japan?").
 */
export declare function CoachSuggestion(props: CoachSuggestionProps): JSX.Element;
