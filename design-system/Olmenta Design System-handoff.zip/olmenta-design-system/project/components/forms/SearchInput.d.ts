import * as React from "react";

export interface SearchInputProps {
  value?: string;
  defaultValue?: string;
  placeholder?: string;
  onChange?: (e: React.ChangeEvent<HTMLInputElement>) => void;
  size?: "sm" | "md";
  style?: React.CSSProperties;
}

/** Pill-shaped search field with a leading magnifier, on a sunk fill. */
export declare function SearchInput(props: SearchInputProps): JSX.Element;
