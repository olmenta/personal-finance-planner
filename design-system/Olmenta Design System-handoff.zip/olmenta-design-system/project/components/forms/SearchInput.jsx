import React from "react";
import { Icon } from "../core/Icon";

/**
 * Rounded search field for lists and transactions. Pill-shaped, sunk fill.
 */
export function SearchInput({ value, defaultValue, placeholder = "Search", onChange, size = "md", style, ...rest }) {
  const h = size === "sm" ? 40 : 46;
  return (
    <span
      style={{
        display: "flex",
        alignItems: "center",
        gap: 9,
        background: "var(--surface-sunk)",
        border: "1px solid transparent",
        borderRadius: "var(--r-full)",
        padding: "0 16px",
        height: h,
        ...style,
      }}
    >
      <Icon name="search" size={18} color="var(--text-subtle)" />
      <input
        value={value}
        defaultValue={defaultValue}
        placeholder={placeholder}
        onChange={onChange}
        style={{
          flex: 1,
          border: "none",
          outline: "none",
          background: "transparent",
          font: "500 15px var(--font-sans)",
          color: "var(--text-strong)",
          minWidth: 0,
        }}
        {...rest}
      />
    </span>
  );
}
