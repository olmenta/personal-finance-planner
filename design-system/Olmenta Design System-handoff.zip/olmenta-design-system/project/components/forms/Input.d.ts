import * as React from "react";
import type { IconName } from "../core/Icon";

export interface InputProps {
  label?: string;
  value?: string;
  defaultValue?: string;
  placeholder?: string;
  type?: string;
  /** Leading icon */
  iconLeft?: IconName;
  /** Static text prefix, e.g. "$" for amounts */
  prefix?: string;
  /** Static text suffix, e.g. "USD" */
  suffix?: string;
  /** Error message — turns the field red */
  error?: string;
  /** Helper text below the field */
  help?: string;
  disabled?: boolean;
  onChange?: (e: React.ChangeEvent<HTMLInputElement>) => void;
  style?: React.CSSProperties;
  inputStyle?: React.CSSProperties;
}

/**
 * Labelled text input. Use `prefix="$"` for money entry. Violet focus ring;
 * error state turns the border red and shows the message.
 */
export declare function Input(props: InputProps): JSX.Element;
