import * as React from "react";
import type { IconName } from "./Icon";

export interface BadgeProps {
  children?: React.ReactNode;
  /** Semantic tone */
  tone?: "brand" | "mint" | "income" | "expense" | "info" | "warning" | "neutral" | "dark";
  /** Solid fill vs soft tinted fill (default) */
  solid?: boolean;
  /** Optional leading icon */
  icon?: IconName;
  /** Show a leading status dot */
  dot?: boolean;
  style?: React.CSSProperties;
}

/**
 * Small pill for status, categories and metadata. Reserve `income`/`expense`
 * tones for money direction only — never decoration. Default tone is neutral.
 */
export declare function Badge(props: BadgeProps): JSX.Element;
