import * as React from "react";
import type { IconName } from "./Icon";

/**
 * @startingPoint section="Core" subtitle="Pill button — primary, accent, ghost, dark" viewport="700x200"
 */
export interface ButtonProps {
  children?: React.ReactNode;
  /** Visual style */
  variant?: "primary" | "accent" | "secondary" | "ghost" | "dark";
  /** Size preset */
  size?: "sm" | "md" | "lg";
  /** Lucide icon name before the label */
  iconLeft?: IconName;
  /** Lucide icon name after the label */
  iconRight?: IconName;
  /** Full-width block button */
  block?: boolean;
  disabled?: boolean;
  type?: "button" | "submit" | "reset";
  onClick?: (e: React.MouseEvent<HTMLButtonElement>) => void;
  style?: React.CSSProperties;
}

/**
 * Primary action control. Always pill-shaped. Use `primary` (violet) for the
 * single most important action on a surface; `accent` (mint) for coach-led
 * positive actions; `ghost` for secondary; `dark` on light hero areas.
 */
export declare function Button(props: ButtonProps): JSX.Element;
