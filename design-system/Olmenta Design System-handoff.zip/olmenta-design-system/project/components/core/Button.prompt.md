Pill action button — use for the primary action on any surface; `accent` for coach-positive actions, `ghost` for secondary.

```jsx
<Button variant="primary" iconLeft="plus">Add transaction</Button>
<Button variant="accent" iconLeft="sparkles">Ask the coach</Button>
<Button variant="ghost" size="sm" iconRight="chevron-right">Details</Button>
<Button variant="dark" block>Continue</Button>
```

Variants: `primary` (violet, default), `accent` (mint), `secondary` (violet-soft fill), `ghost` (hairline border), `dark` (ink). Sizes `sm | md | lg`. Pass `block` for full width, `iconLeft`/`iconRight` with any Olmenta `IconName`.
