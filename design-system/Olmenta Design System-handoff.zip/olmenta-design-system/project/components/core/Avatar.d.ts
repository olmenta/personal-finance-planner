import * as React from "react";

export interface AvatarProps {
  /** Image URL; falls back to initials when absent */
  src?: string;
  /** Full name — used for initials and alt text */
  name?: string;
  /** Diameter in px */
  size?: number;
  /** Status ring */
  ring?: "none" | "brand" | "mint";
  /** Small bottom-right badge node (e.g. an Icon) */
  badge?: React.ReactNode;
  style?: React.CSSProperties;
}

/**
 * User avatar with initials fallback. The mint ring marks the active coach
 * session; the badge slot holds a small wallet/status glyph.
 */
export declare function Avatar(props: AvatarProps): JSX.Element;
