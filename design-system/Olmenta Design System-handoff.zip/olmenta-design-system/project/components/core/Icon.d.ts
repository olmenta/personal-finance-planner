import * as React from "react";

export type IconName =
  | "home" | "wallet" | "pie-chart" | "bar-chart" | "dashboard" | "settings"
  | "plus" | "sparkles" | "bell" | "chevron-down" | "chevron-right" | "chevron-left"
  | "arrow-left" | "arrow-right" | "arrow-up-right" | "arrow-down-left"
  | "trending-up" | "trending-down" | "coffee" | "shopping-bag" | "credit-card"
  | "plane" | "receipt" | "target" | "home2" | "user" | "users" | "send" | "search"
  | "check" | "x" | "more-horizontal" | "info" | "lock" | "eye" | "eye-off"
  | "calendar" | "log-out" | "flame" | "zap" | "piggy-bank" | "building"
  | "dollar-sign" | "filter" | "pin" | "clock" | "arrow-up" | "circle";

export interface IconProps {
  /** Lucide icon name from the Olmenta set */
  name: IconName;
  /** px size (width & height) */
  size?: number;
  /** stroke width — 2 default; 2.25 for small UI, 1.75 for large display */
  strokeWidth?: number;
  /** stroke color; defaults to currentColor */
  color?: string;
  className?: string;
  style?: React.CSSProperties;
}

/**
 * Olmenta's line-icon primitive — Lucide path data, rendered inline so it
 * inherits `currentColor` and scales crisply. The brand icon language is
 * Lucide (2px round-cap stroke). Use `sparkles` for anything coach/AI.
 */
export declare function Icon(props: IconProps): JSX.Element;
export declare const OLMENTA_ICON_NAMES: string[];
