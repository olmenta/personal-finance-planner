import * as React from "react";

export type SegmentOption = string | { label: string; value: string };

export interface SegmentedControlProps {
  /** Options as strings or {label,value} */
  options: SegmentOption[];
  /** Controlled selected value */
  value?: string;
  /** Uncontrolled initial value */
  defaultValue?: string;
  onChange?: (value: string) => void;
  size?: "sm" | "md";
  style?: React.CSSProperties;
}

/**
 * Two-to-four-way toggle for switching a view's lens (e.g. Expenses / Income).
 * The active segment sits on a white pill with a soft shadow.
 */
export declare function SegmentedControl(props: SegmentedControlProps): JSX.Element;
