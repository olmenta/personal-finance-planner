import * as React from "react";
import type { IconName } from "./Icon";

export interface IconButtonProps {
  /** Lucide icon name */
  icon: IconName;
  /** soft = violet tint · ghost = hairline · plain = bare · dark = ink · fab = violet glow */
  variant?: "soft" | "ghost" | "plain" | "dark" | "fab";
  size?: "sm" | "md" | "lg";
  /** pill (true) vs rounded-square (false) */
  round?: boolean;
  disabled?: boolean;
  ariaLabel?: string;
  onClick?: (e: React.MouseEvent<HTMLButtonElement>) => void;
  style?: React.CSSProperties;
}

/**
 * Icon-only button for toolbars, headers and the floating action button.
 * Use `variant="fab"` for the global "add" action — it is the only element
 * allowed to carry the violet glow (`--shadow-fab`).
 */
export declare function IconButton(props: IconButtonProps): JSX.Element;
