import * as React from "react";

export interface SwitchProps {
  /** Controlled state */
  checked?: boolean;
  /** Uncontrolled initial state */
  defaultChecked?: boolean;
  onChange?: (checked: boolean) => void;
  disabled?: boolean;
  size?: "sm" | "md";
  style?: React.CSSProperties;
}

/**
 * Binary toggle for settings. On state is violet; the knob springs across.
 */
export declare function Switch(props: SwitchProps): JSX.Element;
