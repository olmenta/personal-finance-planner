import React from "react";
import { Icon } from "./Icon";

/**
 * Square/circular icon-only button. Variants: soft (violet tint), ghost
 * (hairline), plain (bare), dark. The FAB is `variant="fab"` — the only
 * surface that carries the violet glow shadow.
 */
export function IconButton({
  icon,
  variant = "ghost",
  size = "md",
  round = true,
  disabled = false,
  ariaLabel,
  onClick,
  style,
  ...rest
}) {
  const sizes = { sm: 34, md: 42, lg: 50, fab: 60 };
  const iconSizes = { sm: 18, md: 20, lg: 22, fab: 26 };
  const dim = sizes[size] || sizes.md;

  const variants = {
    soft: { background: "var(--brand-soft)", color: "var(--violet-700)", border: "1px solid transparent", boxShadow: "none" },
    ghost: { background: "var(--surface)", color: "var(--text-body)", border: "1px solid var(--border-hairline)", boxShadow: "var(--shadow-xs)" },
    plain: { background: "transparent", color: "var(--text-body)", border: "1px solid transparent", boxShadow: "none" },
    dark: { background: "var(--ink-900)", color: "#fff", border: "1px solid transparent", boxShadow: "var(--shadow-md)" },
    fab: { background: "var(--brand)", color: "#fff", border: "1px solid transparent", boxShadow: "var(--shadow-fab)" },
  };
  const v = variants[variant] || variants.ghost;
  const isFab = variant === "fab";
  const d = isFab ? sizes.fab : dim;

  return (
    <button
      type="button"
      aria-label={ariaLabel}
      disabled={disabled}
      onClick={onClick}
      style={{
        display: "inline-flex",
        alignItems: "center",
        justifyContent: "center",
        width: d,
        height: d,
        flex: "none",
        borderRadius: round ? "var(--r-full)" : "var(--r-md)",
        cursor: disabled ? "not-allowed" : "pointer",
        opacity: disabled ? 0.45 : 1,
        transition: "transform var(--dur-fast) var(--ease-spring), background var(--dur-base) var(--ease-out)",
        ...v,
        ...style,
      }}
      onMouseDown={(e) => { if (!disabled) e.currentTarget.style.transform = "scale(0.94)"; }}
      onMouseUp={(e) => { e.currentTarget.style.transform = "scale(1)"; }}
      onMouseLeave={(e) => { e.currentTarget.style.transform = "scale(1)"; }}
      {...rest}
    >
      <Icon name={icon} size={isFab ? iconSizes.fab : iconSizes[size] || iconSizes.md} strokeWidth={2.25} />
    </button>
  );
}
