import * as React from "react";
import type { IconName } from "../core/Icon";

export interface BudgetBarProps {
  /** Optional leading category chip */
  icon?: IconName;
  tone?: "violet" | "mint" | "income" | "info" | "warning";
  label: React.ReactNode;
  /** Spent display value, e.g. "$420" */
  spent: React.ReactNode;
  /** Limit display value, e.g. "$600" */
  limit?: React.ReactNode;
  /** Explicit percent 0–100+ (otherwise derived from spent/limit numbers) */
  percent?: number;
  style?: React.CSSProperties;
}

/**
 * Category budget meter. The track fill turns red automatically once spending
 * passes the limit (>100%).
 */
export declare function BudgetBar(props: BudgetBarProps): JSX.Element;
