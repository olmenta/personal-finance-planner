import * as React from "react";
import type { IconName } from "../core/Icon";

export interface StatCardProps {
  icon: IconName;
  tone?: "violet" | "mint" | "income" | "expense" | "info" | "warning" | "neutral";
  label: string;
  value: React.ReactNode;
  /** Show the small info glyph next to the label */
  info?: boolean;
  style?: React.CSSProperties;
}

/** Small money metric card (icon chip + label + tabular value). */
export declare function StatCard(props: StatCardProps): JSX.Element;
