import * as React from "react";

/**
 * @startingPoint section="Finance" subtitle="Gradient hero balance card" viewport="700x240"
 */
export interface BalanceCardProps {
  /** Small label above the amount */
  label?: string;
  /** Integer + thousands part, e.g. "$87,457" */
  amount: React.ReactNode;
  /** Dimmed cents, e.g. ".85" */
  cents?: string;
  /** Delta pill content, e.g. "+$784 than last week" */
  delta?: React.ReactNode;
  deltaTone?: "up" | "down";
  align?: "center" | "left";
  style?: React.CSSProperties;
  children?: React.ReactNode;
}

/**
 * The signature violet-gradient balance hero. Amount uses tabular figures
 * with dimmed cents; the delta sits in a translucent blurred pill.
 */
export declare function BalanceCard(props: BalanceCardProps): JSX.Element;
