import * as React from "react";
import type { IconName } from "../core/Icon";

export interface IconChipProps {
  /** Lucide icon name for the category */
  icon: IconName;
  /** Tinted tone — pick by category meaning */
  tone?: "violet" | "mint" | "income" | "expense" | "info" | "warning" | "neutral";
  /** Square dimension in px */
  size?: number;
  shape?: "rounded" | "circle";
  style?: React.CSSProperties;
}

/**
 * Soft-tinted square with a full-color glyph — the category marker used on
 * every transaction row and money card. Tone follows category, not amount.
 */
export declare function IconChip(props: IconChipProps): JSX.Element;
