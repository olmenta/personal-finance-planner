import React from "react";
import { Icon } from "../core/Icon";

const TONES = {
  violet: ["var(--violet-100)", "var(--violet-600)"],
  mint: ["var(--mint-100)", "var(--mint-600)"],
  income: ["var(--income-soft)", "var(--income)"],
  expense: ["var(--expense-soft)", "var(--expense)"],
  info: ["var(--info-soft)", "var(--info)"],
  warning: ["var(--warning-soft)", "var(--warning)"],
  neutral: ["var(--gray-100)", "var(--ink-700)"],
};

/**
 * Category icon chip: a soft tinted square holding a full-color glyph.
 * The transaction's category decides the tone. This is the signature
 * money-list motif.
 */
export function IconChip({ icon, tone = "neutral", size = 46, shape = "rounded", style }) {
  const [bg, fg] = TONES[tone] || TONES.neutral;
  const radius = shape === "circle" ? "var(--r-full)" : "var(--r-md)";
  return (
    <span
      style={{
        width: size,
        height: size,
        flex: "none",
        borderRadius: radius,
        background: bg,
        color: fg,
        display: "inline-flex",
        alignItems: "center",
        justifyContent: "center",
        ...style,
      }}
    >
      <Icon name={icon} size={size * 0.46} strokeWidth={2.25} />
    </span>
  );
}
