import React from "react";
import { IconChip } from "./IconChip";

/**
 * Budget / category progress bar. Shows spent vs limit with a tinted track;
 * the fill turns to expense-red once over 100%.
 */
export function BudgetBar({ icon, tone = "violet", label, spent, limit, percent, style }) {
  const pct = percent !== undefined ? percent : limit ? Math.round((spent / limit) * 100) : 0;
  const over = pct > 100;
  const fillColor = over ? "var(--expense)" : `var(--${tone === "violet" ? "violet-500" : tone === "mint" ? "mint-500" : tone === "income" ? "income" : tone === "warning" ? "warning" : tone === "info" ? "info" : "violet-500"})`;
  return (
    <div style={{ display: "flex", alignItems: "center", gap: 13, ...style }}>
      {icon && <IconChip icon={icon} tone={over ? "expense" : tone} size={40} />}
      <div style={{ flex: 1, minWidth: 0 }}>
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "baseline", marginBottom: 7 }}>
          <span style={{ font: "600 14px var(--font-sans)", color: "var(--text-strong)", letterSpacing: "-0.1px" }}>{label}</span>
          <span style={{ font: "600 13px var(--font-sans)", color: over ? "var(--expense)" : "var(--text-muted)", fontVariantNumeric: "tabular-nums" }}>
            {spent}{limit ? <span style={{ color: "var(--text-subtle)", fontWeight: 500 }}> / {limit}</span> : null}
          </span>
        </div>
        <div style={{ height: 8, borderRadius: "var(--r-full)", background: "var(--gray-100)", overflow: "hidden" }}>
          <div style={{ width: `${Math.min(pct, 100)}%`, height: "100%", borderRadius: "var(--r-full)", background: fillColor, transition: "width var(--dur-slow) var(--ease-out)" }} />
        </div>
      </div>
    </div>
  );
}
