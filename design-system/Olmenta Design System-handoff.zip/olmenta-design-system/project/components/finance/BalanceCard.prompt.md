The violet-gradient hero balance — the anchor of the Olmenta home screen.

```jsx
<BalanceCard
  label="Current balance"
  amount="$87,457"
  cents=".85"
  delta="↑ $784 than last week"
/>
```

Amount uses tabular figures with dimmed cents. Keep one per screen. The delta pill is translucent on the gradient; use a short comparison string.
