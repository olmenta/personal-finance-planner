import * as React from "react";
import type { IconName } from "../core/Icon";

/**
 * @startingPoint section="Finance" subtitle="Transaction list row" viewport="700x90"
 */
export interface TransactionRowProps {
  icon: IconName;
  tone?: "violet" | "mint" | "income" | "expense" | "info" | "warning" | "neutral";
  title: React.ReactNode;
  /** Sub-line — can hold a Badge, account name, etc. */
  subtitle?: React.ReactNode;
  /** Amount without sign, e.g. "354.25$" */
  amount: React.ReactNode;
  /** in = green +, out = red −, neutral = ink */
  direction?: "in" | "out" | "neutral";
  /** Optional running balance shown under the amount */
  balance?: React.ReactNode;
  /** Wrap in its own card surface (default) or render bare for grouped lists */
  card?: boolean;
  onClick?: () => void;
  style?: React.CSSProperties;
}

/**
 * A single money movement. Amount color is driven by `direction` — never
 * decoration. Use `card={false}` inside a grouped, divided list.
 */
export declare function TransactionRow(props: TransactionRowProps): JSX.Element;
