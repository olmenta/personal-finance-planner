One money movement in a list. Amount color comes from `direction` — never set it manually.

```jsx
<TransactionRow icon="coffee" tone="info" title="Cafés"
  subtitle={<Badge tone="neutral" dot>Vacation</Badge>}
  amount="12.49" direction="out" />
<TransactionRow icon="dollar-sign" tone="income" title="Salary"
  amount="4,875.12" direction="in" balance="$9,120.33" />
```

`direction`: `in` = green +, `out` = red −, `neutral` = ink. Use `card={false}` for rows inside a single grouped list container. `tone` follows the category, not the amount.
