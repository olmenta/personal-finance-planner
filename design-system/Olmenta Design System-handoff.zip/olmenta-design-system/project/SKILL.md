---
name: olmenta-design
description: Use this skill to generate well-branded interfaces and assets for Olmenta — an AI personal finance coach (iOS + web) — either for production or throwaway prototypes/mocks/etc. Contains essential design guidelines, colors, type, fonts, assets, and UI kit components for prototyping.
user-invocable: true
---

Read the `readme.md` file within this skill, and explore the other available files.

If creating visual artifacts (slides, mocks, throwaway prototypes, etc), copy assets out and create static HTML files for the user to view. If working on production code, you can copy assets and read the rules here to become an expert in designing with this brand.

If the user invokes this skill without any other guidance, ask them what they want to build or design, ask some questions, and act as an expert designer who outputs HTML artifacts _or_ production code, depending on the need.

## What's here
- `readme.md` — the full design guide: brand, content voice, visual foundations, iconography, file index, principles, caveats. **Start here.**
- `styles.css` — the single global stylesheet to link. `@import`s every token + font.
- `tokens/` — colors, typography, spacing/radii/shadows/motion, base reset.
- `components/` — React primitives (core, forms, finance, coach). Each has a `.jsx`, a `.d.ts` props contract, and most a `.prompt.md` usage note.
- `guidelines/` — foundation specimen cards (Type, Colors, Spacing, Brand).
- `ui_kits/mobile_app/` and `ui_kits/web_app/` — full interactive product recreations to crib from.
- `assets/` — the Olmenta logo mark.

## Quick brand cheat-sheet
- **Violet `#7C5CFC`** = primary action + balance. **Mint `#16C79A`** = the coach, growth. Spend violet in one place.
- **Money drives color**: income green `#18BE7C`, expense red `#F2503C` — never decoration.
- **Type**: Inter everywhere; tabular figures for money; Geist Mono for metadata. Sentence case; UPPERCASE only for tiny eyebrows.
- **Icons**: Lucide (2px stroke). The **sparkle** is reserved for the AI coach.
- **Feel**: calm premium fintech, generous radii (cards 24px, pills everywhere), soft violet-tinted shadows, friendly + human coach voice.
- **Signature**: the dark sparkle-led **Coach** capsule and the conversational coach.

To consume components in an HTML file: link `styles.css`, load `_ds_bundle.js`, then `const { Button, BalanceCard, CoachCapsule } = window.OlmentaDesignSystem_4bdf9c;`.
