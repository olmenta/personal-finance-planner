/* Olmenta mobile — Coach: the conversational AI surface. */
const {
  CoachMessage, CoachSuggestion, IconButton, Icon, BudgetBar, Button,
} = window.OlmentaDesignSystem_4bdf9c;

function CoachHeader({ onBack }) {
  return (
    <div style={{ display: "flex", alignItems: "center", gap: 12, padding: "6px 20px 16px", borderBottom: "1px solid var(--border-hairline)" }}>
      <IconButton icon="arrow-left" variant="ghost" size="sm" ariaLabel="Back" onClick={onBack} />
      <span style={{ width: 40, height: 40, borderRadius: 999, background: "var(--grad-coach)", display: "flex", alignItems: "center", justifyContent: "center", flex: "none" }}>
        <Icon name="sparkles" size={19} color="var(--mint-400)" />
      </span>
      <div style={{ flex: 1 }}>
        <div style={{ font: "700 16px var(--font-sans)", letterSpacing: "-0.3px", color: "var(--text-strong)" }}>Coach</div>
        <div style={{ display: "flex", alignItems: "center", gap: 5, font: "500 12px var(--font-sans)", color: "var(--mint-600)" }}>
          <span style={{ width: 7, height: 7, borderRadius: 999, background: "var(--mint-500)" }} /> Always here
        </div>
      </div>
      <IconButton icon="more-horizontal" variant="ghost" size="sm" ariaLabel="More" />
    </div>
  );
}

function CoachScreen({ onBack }) {
  const [draft, setDraft] = React.useState("");
  return (
    <div style={{ flex: 1, display: "flex", flexDirection: "column", background: "var(--bg)", minHeight: 0 }}>
      <StatusBar />
      <CoachHeader onBack={onBack} />
      <div style={{ flex: 1, overflowY: "auto", padding: "18px 18px", display: "flex", flexDirection: "column", gap: 14 }}>
        <div style={{ textAlign: "center", font: "500 11.5px var(--font-mono)", color: "var(--text-subtle)", letterSpacing: "0.3px" }}>TODAY · 9:41</div>
        <CoachMessage role="coach">Morning, Maya 👋 Your dining spend is up <b>18%</b> this month — mostly cafés on weekends.</CoachMessage>
        <CoachMessage role="coach">
          <div style={{ marginBottom: 10 }}>Here's where Food &amp; dining sits against your budget:</div>
          <div style={{ background: "var(--bg)", borderRadius: "var(--r-md)", padding: "12px 12px" }}>
            <BudgetBar icon="coffee" tone="warning" label="Food & dining" spent="$8,846" limit="$9,000" />
          </div>
        </CoachMessage>
        <CoachMessage role="user">Yikes. Can you cap it?</CoachMessage>
        <CoachMessage role="coach">On it. I'll set a <b>$300 weekly cap</b> and nudge you at 80%. You're still on track for your Japan goal 🎌</CoachMessage>
        <div style={{ paddingLeft: 40 }}>
          <Button variant="accent" size="sm" iconLeft="check">Set the $300 cap</Button>
        </div>
      </div>

      <div style={{ flex: "none", padding: "12px 16px 14px", borderTop: "1px solid var(--border-hairline)", background: "var(--surface)" }}>
        <div style={{ marginBottom: 12 }}>
          <CoachSuggestion suggestions={[
            { label: "Where can I cut back?", icon: "trending-down" },
            { label: "On track for Japan?", icon: "plane" },
          ]} onPick={setDraft} />
        </div>
        <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
          <span style={{ flex: 1, display: "flex", alignItems: "center", gap: 9, background: "var(--surface-sunk)", borderRadius: 999, padding: "0 16px", height: 48 }}>
            <input value={draft} onChange={(e) => setDraft(e.target.value)} placeholder="Ask the coach anything…" style={{ flex: 1, border: "none", outline: "none", background: "transparent", font: "500 15px var(--font-sans)", color: "var(--text-strong)", minWidth: 0 }} />
          </span>
          <IconButton icon="send" variant="fab" size="md" ariaLabel="Send" />
        </div>
      </div>
    </div>
  );
}

Object.assign(window, { CoachScreen });
