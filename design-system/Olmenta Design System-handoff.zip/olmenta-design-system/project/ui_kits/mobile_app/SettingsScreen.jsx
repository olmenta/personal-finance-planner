/* Olmenta mobile — Settings: profile, preferences, coach controls. */
const { Avatar, Switch, Icon, Badge, IconChip } = window.OlmentaDesignSystem_4bdf9c;

function Row({ icon, tone, label, sub, right, last }) {
  return (
    <div style={{ display: "flex", alignItems: "center", gap: 13, padding: "13px 0", borderBottom: last ? "none" : "1px solid var(--border-hairline)" }}>
      <IconChip icon={icon} tone={tone} size={38} />
      <div style={{ flex: 1, minWidth: 0 }}>
        <div style={{ font: "600 15px var(--font-sans)", color: "var(--text-strong)", letterSpacing: "-0.1px" }}>{label}</div>
        {sub && <div style={{ font: "500 12.5px var(--font-sans)", color: "var(--text-muted)", marginTop: 1 }}>{sub}</div>}
      </div>
      {right}
    </div>
  );
}

function SettingsScreen() {
  return (
    <div style={{ flex: 1, overflowY: "auto", overflowX: "hidden", background: "var(--bg)" }}>
      <StatusBar />
      <div style={{ padding: "6px 20px 24px" }}>
        <span style={{ font: "700 22px var(--font-sans)", letterSpacing: "-0.5px", color: "var(--text-strong)" }}>Settings</span>

        <div style={{ background: "var(--surface)", border: "1px solid var(--border-hairline)", borderRadius: "var(--r-xl)", padding: 18, boxShadow: "var(--shadow-sm)", marginTop: 16, display: "flex", alignItems: "center", gap: 14 }}>
          <Avatar name="Maya Ortiz" ring="brand" size={56} />
          <div style={{ flex: 1 }}>
            <div style={{ font: "700 17px var(--font-sans)", letterSpacing: "-0.3px", color: "var(--text-strong)" }}>Maya Ortiz</div>
            <div style={{ font: "500 13px var(--font-sans)", color: "var(--text-muted)", marginTop: 1 }}>maya@olmenta.app</div>
          </div>
          <Badge tone="mint" icon="sparkles">Pro</Badge>
        </div>

        <div style={{ font: "var(--t-eyebrow-fw) var(--t-eyebrow-size)/1 var(--font-sans)", letterSpacing: "var(--t-eyebrow-ls)", textTransform: "uppercase", color: "var(--text-subtle)", margin: "24px 2px 6px" }}>Coach</div>
        <div style={{ background: "var(--surface)", border: "1px solid var(--border-hairline)", borderRadius: "var(--r-xl)", padding: "4px 16px", boxShadow: "var(--shadow-sm)" }}>
          <Row icon="sparkles" tone="violet" label="Proactive insights" sub="Let the coach reach out" right={<Switch defaultChecked />} />
          <Row icon="bell" tone="info" label="Spending nudges" sub="When you near a cap" right={<Switch defaultChecked />} last />
        </div>

        <div style={{ font: "var(--t-eyebrow-fw) var(--t-eyebrow-size)/1 var(--font-sans)", letterSpacing: "var(--t-eyebrow-ls)", textTransform: "uppercase", color: "var(--text-subtle)", margin: "24px 2px 6px" }}>Account</div>
        <div style={{ background: "var(--surface)", border: "1px solid var(--border-hairline)", borderRadius: "var(--r-xl)", padding: "4px 16px", boxShadow: "var(--shadow-sm)" }}>
          <Row icon="wallet" tone="violet" label="Accounts & cards" sub="3 linked" right={<Icon name="chevron-right" size={18} color="var(--text-subtle)" />} />
          <Row icon="target" tone="mint" label="Goals" sub="Japan trip · 68%" right={<Icon name="chevron-right" size={18} color="var(--text-subtle)" />} />
          <Row icon="lock" tone="neutral" label="Privacy & security" right={<Icon name="chevron-right" size={18} color="var(--text-subtle)" />} last />
        </div>
      </div>
    </div>
  );
}

Object.assign(window, { SettingsScreen });
