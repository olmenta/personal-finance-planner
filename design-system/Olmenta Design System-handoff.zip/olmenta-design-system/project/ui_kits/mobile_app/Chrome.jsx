/* Mobile app chrome: iOS status bar, phone frame, and the pinned bottom nav. */
const { Icon, IconButton } = window.OlmentaDesignSystem_4bdf9c;

function StatusBar({ dark = false }) {
  const color = dark ? "#fff" : "var(--ink-900)";
  return (
    <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", padding: "14px 28px 6px", height: 44 }}>
      <span style={{ font: "700 15px var(--font-sans)", color, letterSpacing: "0.2px" }}>9:41</span>
      <div style={{ display: "flex", alignItems: "center", gap: 6, color }}>
        <svg width="18" height="12" viewBox="0 0 18 12" fill="none"><rect x="0" y="7" width="3" height="5" rx="1" fill="currentColor"/><rect x="5" y="4.5" width="3" height="7.5" rx="1" fill="currentColor"/><rect x="10" y="2" width="3" height="10" rx="1" fill="currentColor"/><rect x="15" y="0" width="3" height="12" rx="1" fill="currentColor" opacity="0.35"/></svg>
        <svg width="17" height="12" viewBox="0 0 17 12" fill="none"><path d="M8.5 2.5c2.3 0 4.4.9 6 2.4l-1.4 1.4a6.6 6.6 0 0 0-9.2 0L2.5 4.9A8.6 8.6 0 0 1 8.5 2.5Z" fill="currentColor"/><path d="M8.5 6.2c1.3 0 2.5.5 3.3 1.4l-3.3 3.3-3.3-3.3A4.6 4.6 0 0 1 8.5 6.2Z" fill="currentColor"/></svg>
        <svg width="26" height="13" viewBox="0 0 26 13" fill="none"><rect x="0.5" y="0.5" width="22" height="12" rx="3.5" stroke="currentColor" opacity="0.4"/><rect x="2" y="2" width="17" height="9" rx="2" fill="currentColor"/><rect x="24" y="4" width="1.5" height="5" rx="0.75" fill="currentColor" opacity="0.4"/></svg>
      </div>
    </div>
  );
}

function PhoneFrame({ children, dark = false }) {
  return (
    <div style={{ width: 390, borderRadius: 54, padding: 11, background: "#0C0B10", boxShadow: "0 40px 90px rgba(40,30,80,.30), 0 8px 24px rgba(40,30,80,.18)" }}>
      <div style={{ position: "relative", borderRadius: 44, overflow: "hidden", background: dark ? "var(--ink-900)" : "var(--bg)", height: 800, display: "flex", flexDirection: "column" }}>
        <div style={{ position: "absolute", top: 11, left: "50%", transform: "translateX(-50%)", width: 116, height: 33, background: "#0C0B10", borderRadius: 999, zIndex: 50 }} />
        {children}
      </div>
    </div>
  );
}

function BottomNav({ active, onChange }) {
  const items = [
    { key: "home", icon: "home", label: "Home" },
    { key: "report", icon: "pie-chart", label: "Report" },
    { key: "coach", icon: "sparkles", label: "Coach" },
    { key: "settings", icon: "settings", label: "Settings" },
  ];
  return (
    <div style={{ position: "relative", display: "flex", alignItems: "center", justifyContent: "space-around", background: "var(--surface)", borderTop: "1px solid var(--border-hairline)", padding: "12px 14px 26px", flex: "none" }}>
      {items.slice(0, 2).map((it) => <NavItem key={it.key} {...it} active={active === it.key} onClick={() => onChange(it.key)} />)}
      <div style={{ width: 60, flex: "none" }} />
      {items.slice(2).map((it) => <NavItem key={it.key} {...it} active={active === it.key} onClick={() => onChange(it.key)} />)}
      <div style={{ position: "absolute", top: -18, left: "50%", transform: "translateX(-50%)" }}>
        <IconButton icon="plus" variant="fab" ariaLabel="Add transaction" onClick={() => onChange("add")} />
      </div>
    </div>
  );
}

function NavItem({ icon, label, active, onClick }) {
  return (
    <button type="button" onClick={onClick} style={{ display: "flex", flexDirection: "column", alignItems: "center", gap: 4, background: "none", border: "none", cursor: "pointer", minWidth: 56 }}>
      <Icon name={icon} size={22} color={active ? "var(--violet-600)" : "var(--gray-400)"} strokeWidth={active ? 2.4 : 2} />
      <span style={{ font: `${active ? 700 : 600} 11px var(--font-sans)`, color: active ? "var(--ink-900)" : "var(--gray-400)" }}>{label}</span>
    </button>
  );
}

Object.assign(window, { StatusBar, PhoneFrame, BottomNav, NavItem });
