/* Olmenta mobile — Home: gradient balance header + white sheet with money,
   the coach capsule, and the transaction feed. */
const {
  BalanceCard, StatCard, CoachCapsule, TransactionRow, Avatar, IconButton,
  Icon, Badge,
} = window.OlmentaDesignSystem_4bdf9c;

function HomeHeader() {
  return (
    <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", padding: "6px 22px 0" }}>
      <div style={{ display: "flex", alignItems: "center", gap: 11 }}>
        <Avatar name="Maya Ortiz" size={42} badge={<Icon name="wallet" size={11} color="#fff" />} />
        <div>
          <div style={{ font: "500 12px var(--font-sans)", color: "rgba(255,255,255,.75)" }}>Welcome back</div>
          <div style={{ font: "700 15px var(--font-sans)", color: "#fff", letterSpacing: "-0.2px" }}>Maya Ortiz</div>
        </div>
      </div>
      <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
        <button type="button" style={{ display: "flex", alignItems: "center", gap: 6, background: "rgba(255,255,255,.16)", border: "none", borderRadius: 999, padding: "8px 13px", color: "#fff", font: "600 13px var(--font-sans)", cursor: "pointer", backdropFilter: "blur(6px)" }}>
          November 2025 <Icon name="chevron-down" size={15} />
        </button>
        <button type="button" style={{ position: "relative", width: 40, height: 40, borderRadius: 999, background: "rgba(255,255,255,.16)", border: "none", display: "flex", alignItems: "center", justifyContent: "center", color: "#fff", cursor: "pointer", backdropFilter: "blur(6px)" }}>
          <Icon name="bell" size={19} />
          <span style={{ position: "absolute", top: 9, right: 10, width: 8, height: 8, borderRadius: 999, background: "var(--expense)", border: "1.5px solid var(--violet-500)" }} />
        </button>
      </div>
    </div>
  );
}

function HomeScreen({ onOpenCoach }) {
  return (
    <div style={{ flex: 1, overflowY: "auto", overflowX: "hidden", background: "var(--bg)" }}>
      {/* Violet gradient top */}
      <div style={{ background: "var(--grad-violet)", padding: "0 0 60px" }}>
        <StatusBar dark />
        <HomeHeader />
        <div style={{ textAlign: "center", marginTop: 22 }}>
          <div style={{ font: "500 14px var(--font-sans)", color: "rgba(255,255,255,.8)" }}>Current balance</div>
          <div style={{ font: "800 46px var(--font-sans)", letterSpacing: "-1.8px", color: "#fff", marginTop: 6, fontVariantNumeric: "tabular-nums" }}>
            $87,457<span style={{ opacity: 0.55 }}>.85</span>
          </div>
          <span style={{ display: "inline-flex", alignItems: "center", gap: 5, background: "rgba(255,255,255,.18)", color: "#fff", padding: "7px 14px", borderRadius: 999, font: "600 13px var(--font-sans)", marginTop: 12, backdropFilter: "blur(6px)" }}>
            <Icon name="trending-up" size={15} /> $784 than last week
          </span>
        </div>
      </div>

      {/* White sheet */}
      <div style={{ background: "var(--bg)", borderRadius: "30px 30px 0 0", marginTop: -34, padding: "24px 20px 24px", position: "relative" }}>
        <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginBottom: 14 }}>
          <div style={{ display: "flex", alignItems: "center", gap: 6 }}>
            <span style={{ font: "700 19px var(--font-sans)", letterSpacing: "-0.4px", color: "var(--text-strong)" }}>Your money</span>
            <Icon name="info" size={15} color="var(--text-subtle)" />
          </div>
          <button type="button" style={{ display: "flex", alignItems: "center", gap: 3, background: "var(--surface)", border: "1px solid var(--border-hairline)", borderRadius: 999, padding: "7px 13px", font: "600 13px var(--font-sans)", color: "var(--text-body)", cursor: "pointer" }}>
            Details <Icon name="chevron-right" size={15} />
          </button>
        </div>

        <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 12 }}>
          <StatCard icon="trending-up" tone="income" label="Income" value="$4,875.12" />
          <StatCard icon="trending-down" tone="expense" label="Expenses" value="$8,145.78" />
        </div>

        <div style={{ marginTop: 16 }}>
          <CoachCapsule message="You're spending 18% more on dining" cta="See why" onClick={onOpenCoach} />
        </div>

        <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", margin: "24px 0 14px" }}>
          <span style={{ font: "700 19px var(--font-sans)", letterSpacing: "-0.4px", color: "var(--text-strong)" }}>Transactions</span>
          <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
            <IconButton icon="pin" variant="ghost" size="sm" ariaLabel="Pinned" />
            <IconButton icon="clock" variant="ghost" size="sm" ariaLabel="Recent" />
            <Badge tone="brand" dot>For the period</Badge>
          </div>
        </div>

        <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", margin: "0 2px 12px" }}>
          <span style={{ font: "500 13px var(--font-sans)", color: "var(--text-muted)" }}>Monday, 12 January 2026</span>
          <span style={{ font: "500 12.5px var(--font-mono)", color: "var(--text-subtle)" }}>Total $2,95,776</span>
        </div>

        <div style={{ display: "flex", flexDirection: "column", gap: 10 }}>
          <TransactionRow icon="wallet" tone="violet" title="Cash, EUR" subtitle="↳ Red Card" amount="354.25" direction="out" balance="$4,245.21" />
          <TransactionRow icon="coffee" tone="info" title="Cafés" subtitle={<Badge tone="neutral" dot>Vacation</Badge>} amount="12.49" direction="out" />
          <TransactionRow icon="dollar-sign" tone="income" title="Salary" subtitle="↳ Main account" amount="4,875.12" direction="in" />
          <TransactionRow icon="shopping-bag" tone="violet" title="Shopping" subtitle="↳ Apple Card" amount="129.00" direction="out" />
        </div>
      </div>
    </div>
  );
}

Object.assign(window, { HomeScreen });
