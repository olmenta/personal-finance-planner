/* Olmenta mobile — Report: expenses/income lens, donut breakdown, categories. */
const {
  SegmentedControl, IconButton, Icon, IconChip, BudgetBar, Badge,
} = window.OlmentaDesignSystem_4bdf9c;

function Donut() {
  return (
    <div style={{ display: "flex", flexDirection: "column", alignItems: "center", padding: "8px 0 4px" }}>
      <div style={{ position: "relative", width: 210, height: 210, borderRadius: "50%",
        background: "conic-gradient(var(--chart-1) 0 31%, var(--chart-3) 31% 55%, var(--chart-2) 55% 76%, var(--chart-4) 76% 90%, var(--chart-empty) 90% 100%)",
        display: "flex", alignItems: "center", justifyContent: "center" }}>
        <div style={{ width: 132, height: 132, background: "var(--surface)", borderRadius: "50%", display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center" }}>
          <span style={{ font: "500 12px var(--font-sans)", color: "var(--text-muted)" }}>Total expenses</span>
          <span style={{ font: "800 24px var(--font-sans)", letterSpacing: "-0.8px", color: "var(--text-strong)", fontVariantNumeric: "tabular-nums" }}>$42,124</span>
        </div>
        <span style={{ position: "absolute", top: 18, right: 4, background: "var(--ink-900)", color: "#fff", font: "700 12px var(--font-mono)", padding: "5px 10px", borderRadius: 999 }}>31%</span>
      </div>
    </div>
  );
}

function ReportScreen() {
  const cats = [
    { icon: "shopping-bag", tone: "violet", label: "Shopping", spent: "$13,058", limit: "$15,000" },
    { icon: "receipt", tone: "info", label: "Bills & utilities", spent: "$10,109", limit: "$10,000" },
    { icon: "coffee", tone: "mint", label: "Food & dining", spent: "$8,846", limit: "$12,000" },
    { icon: "plane", tone: "warning", label: "Travel", spent: "$5,897", limit: "$8,000" },
  ];
  return (
    <div style={{ flex: 1, overflowY: "auto", overflowX: "hidden", background: "var(--bg)" }}>
      <StatusBar />
      <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", padding: "6px 20px 0" }}>
        <div style={{ display: "flex", alignItems: "center", gap: 12 }}>
          <IconButton icon="arrow-left" variant="ghost" size="sm" ariaLabel="Back" />
          <span style={{ font: "700 22px var(--font-sans)", letterSpacing: "-0.5px", color: "var(--text-strong)" }}>Report</span>
        </div>
        <button type="button" style={{ display: "flex", alignItems: "center", gap: 6, background: "var(--surface)", border: "1px solid var(--border-hairline)", borderRadius: 999, padding: "8px 13px", color: "var(--text-body)", font: "600 13px var(--font-sans)", cursor: "pointer" }}>
          November 2025 <Icon name="chevron-down" size={15} />
        </button>
      </div>

      <div style={{ padding: "18px 20px 24px" }}>
        <SegmentedControl options={["Expenses", "Income"]} defaultValue="Expenses" />

        <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", margin: "22px 0 4px" }}>
          <span style={{ font: "700 18px var(--font-sans)", letterSpacing: "-0.3px", color: "var(--text-strong)" }}>Expenses report</span>
          <div style={{ display: "flex", background: "var(--surface-sunk)", borderRadius: 999, padding: 4, gap: 2 }}>
            <span style={{ width: 34, height: 34, borderRadius: 999, display: "flex", alignItems: "center", justifyContent: "center", color: "var(--text-muted)" }}><Icon name="bar-chart" size={17} /></span>
            <span style={{ width: 34, height: 34, borderRadius: 999, background: "var(--surface)", boxShadow: "var(--shadow-sm)", display: "flex", alignItems: "center", justifyContent: "center", color: "var(--violet-600)" }}><Icon name="pie-chart" size={17} /></span>
          </div>
        </div>

        <Donut />

        <div style={{ display: "flex", flexWrap: "wrap", gap: 10, justifyContent: "center", margin: "18px 0 4px" }}>
          {[["var(--chart-1)", "Shopping 31%"], ["var(--chart-3)", "Bills 24%"], ["var(--chart-2)", "Food 21%"], ["var(--chart-4)", "Travel 14%"], ["var(--chart-empty)", "Other 10%"]].map(([c, l]) => (
            <span key={l} style={{ display: "flex", alignItems: "center", gap: 6, font: "500 12px var(--font-sans)", color: "var(--text-muted)" }}>
              <span style={{ width: 10, height: 10, borderRadius: 3, background: c }} /> {l}
            </span>
          ))}
        </div>

        <div style={{ background: "var(--surface)", border: "1px solid var(--border-hairline)", borderRadius: "var(--r-xl)", padding: "18px 18px", boxShadow: "var(--shadow-sm)", marginTop: 18 }}>
          <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginBottom: 16 }}>
            <span style={{ font: "700 16px var(--font-sans)", letterSpacing: "-0.3px", color: "var(--text-strong)" }}>By category</span>
            <Badge tone="brand">5 categories</Badge>
          </div>
          <div style={{ display: "flex", flexDirection: "column", gap: 17 }}>
            {cats.map((c) => <BudgetBar key={c.label} {...c} />)}
          </div>
        </div>
      </div>
    </div>
  );
}

Object.assign(window, { ReportScreen });
