# Olmenta — Mobile App UI kit (iOS)

High-fidelity recreation of the Olmenta iOS app, composed entirely from the design-system components.

## Screens
- **HomeScreen** — violet gradient balance header → white sheet with *Your money* stat cards, the **Coach capsule**, and the transaction feed.
- **ReportScreen** — Expenses / Income lens, conic donut breakdown, per-category budget bars.
- **CoachScreen** — the conversational AI coach: chat bubbles, an embedded budget card, prompt suggestions, and a send bar.
- **SettingsScreen** — profile, coach controls (switches), accounts & goals.
- **Chrome** — `StatusBar`, `PhoneFrame`, `BottomNav` (Home · Report · center FAB · Coach · Settings).

## Run it
Open `index.html`. The bottom nav switches screens, the **+** FAB opens the *Add transaction* sheet, the home Coach capsule and the Coach nav item open the chat.

## Components used
`BalanceCard, StatCard, TransactionRow, IconChip, BudgetBar, CoachCapsule, CoachMessage, CoachSuggestion, SegmentedControl, Input, Button, IconButton, Avatar, Switch, Badge, Icon`.

Design width **390px**. The phone frame scales to fit its container.
