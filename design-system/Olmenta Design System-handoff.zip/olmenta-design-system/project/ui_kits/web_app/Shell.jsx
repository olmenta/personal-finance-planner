/* Olmenta web — shell chrome: left sidebar + top bar. */
const { Icon, Avatar, SearchInput, Badge, IconButton } = window.OlmentaDesignSystem_4bdf9c;

function Logo() {
  return (
    <div style={{ display: "flex", alignItems: "center", gap: 11, padding: "4px 8px 0" }}>
      <img src={(window.__resources && window.__resources.logoMark) || "../../assets/olmenta-mark.svg"} width="34" height="34" alt="Olmenta" />
      <span style={{ font: "800 21px var(--font-sans)", letterSpacing: "-1px", color: "var(--ink-900)" }}>Olmenta</span>
    </div>
  );
}

function SideItem({ icon, label, active, onClick }) {
  return (
    <button type="button" onClick={onClick} style={{
      display: "flex", alignItems: "center", gap: 12, width: "100%", textAlign: "left",
      padding: "11px 13px", borderRadius: "var(--r-md)", border: "none", cursor: "pointer",
      background: active ? "var(--violet-100)" : "transparent",
      color: active ? "var(--violet-700)" : "var(--text-muted)",
      font: `${active ? 700 : 600} 14.5px var(--font-sans)`, letterSpacing: "-0.1px",
      transition: "background var(--dur-base) var(--ease-out), color var(--dur-base) var(--ease-out)",
    }}
    onMouseEnter={(e) => { if (!active) { e.currentTarget.style.background = "var(--violet-50)"; e.currentTarget.style.color = "var(--text-body)"; } }}
    onMouseLeave={(e) => { if (!active) { e.currentTarget.style.background = "transparent"; e.currentTarget.style.color = "var(--text-muted)"; } }}>
      <Icon name={icon} size={20} strokeWidth={active ? 2.4 : 2} />
      {label}
    </button>
  );
}

function Sidebar({ active, onChange }) {
  const items = [
    { key: "overview", icon: "dashboard", label: "Overview" },
    { key: "transactions", icon: "receipt", label: "Transactions" },
    { key: "budgets", icon: "pie-chart", label: "Budgets" },
    { key: "goals", icon: "target", label: "Goals" },
  ];
  return (
    <aside style={{ width: 264, flex: "none", background: "var(--surface)", borderRight: "1px solid var(--border-hairline)", padding: "22px 16px", display: "flex", flexDirection: "column", height: "100%" }}>
      <Logo />
      <nav style={{ display: "flex", flexDirection: "column", gap: 3, marginTop: 26 }}>
        <div style={{ font: "var(--t-eyebrow-fw) var(--t-eyebrow-size)/1 var(--font-sans)", letterSpacing: "var(--t-eyebrow-ls)", textTransform: "uppercase", color: "var(--text-subtle)", padding: "0 13px 8px" }}>Menu</div>
        {items.map((it) => <SideItem key={it.key} {...it} active={active === it.key} onClick={() => onChange(it.key)} />)}
      </nav>

      <div style={{ marginTop: "auto", display: "flex", flexDirection: "column", gap: 14 }}>
        <div style={{ background: "var(--grad-coach)", borderRadius: "var(--r-xl)", padding: 16, color: "#fff" }}>
          <span style={{ display: "inline-flex", width: 30, height: 30, borderRadius: "var(--r-sm)", background: "rgba(255,255,255,.1)", alignItems: "center", justifyContent: "center", marginBottom: 10 }}>
            <Icon name="sparkles" size={16} color="var(--mint-400)" />
          </span>
          <div style={{ font: "700 14.5px var(--font-sans)", letterSpacing: "-0.2px" }}>Olmenta Pro</div>
          <div style={{ font: "500 12.5px/1.45 var(--font-sans)", color: "rgba(255,255,255,.7)", margin: "4px 0 12px" }}>Deeper coaching, unlimited goals.</div>
          <button type="button" style={{ width: "100%", background: "#fff", color: "var(--ink-900)", border: "none", borderRadius: 999, padding: "9px", font: "600 13.5px var(--font-sans)", cursor: "pointer" }}>Upgrade</button>
        </div>
        <div style={{ display: "flex", alignItems: "center", gap: 11, padding: "8px 6px" }}>
          <Avatar name="Maya Ortiz" size={38} />
          <div style={{ flex: 1, minWidth: 0 }}>
            <div style={{ font: "700 13.5px var(--font-sans)", color: "var(--text-strong)" }}>Maya Ortiz</div>
            <div style={{ font: "500 12px var(--font-sans)", color: "var(--text-muted)", overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>maya@olmenta.app</div>
          </div>
          <Icon name="settings" size={18} color="var(--text-subtle)" />
        </div>
      </div>
    </aside>
  );
}

function TopBar({ title, sub }) {
  return (
    <header style={{ display: "flex", alignItems: "center", justifyContent: "space-between", padding: "22px 28px", borderBottom: "1px solid var(--border-hairline)", background: "var(--surface)" }}>
      <div>
        <h1 style={{ font: "700 24px var(--font-sans)", letterSpacing: "-0.6px", color: "var(--text-strong)" }}>{title}</h1>
        {sub && <div style={{ font: "500 13.5px var(--font-sans)", color: "var(--text-muted)", marginTop: 2 }}>{sub}</div>}
      </div>
      <div style={{ display: "flex", alignItems: "center", gap: 12 }}>
        <div style={{ width: 240 }}><SearchInput placeholder="Search transactions" /></div>
        <button type="button" style={{ display: "flex", alignItems: "center", gap: 7, background: "var(--surface)", border: "1px solid var(--border-hairline)", borderRadius: 999, padding: "9px 14px", color: "var(--text-body)", font: "600 13.5px var(--font-sans)", cursor: "pointer" }}>
          <Icon name="calendar" size={16} color="var(--text-muted)" /> November 2025 <Icon name="chevron-down" size={15} color="var(--text-subtle)" />
        </button>
        <IconButton icon="bell" variant="ghost" />
      </div>
    </header>
  );
}

Object.assign(window, { Logo, Sidebar, TopBar });
