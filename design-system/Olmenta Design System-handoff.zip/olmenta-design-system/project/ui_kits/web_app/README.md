# Olmenta — Web App UI kit

High-fidelity recreation of the Olmenta web dashboard, composed from the design-system components.

## Layout
A desktop app window: **Sidebar** (logo, nav, Pro card, user) · **main** (TopBar + scrollable content) · a **persistent Coach rail** on the right.

## Screens
- **Dashboard** (Overview) — gradient balance hero, income/expense stats, a spending bar chart, budgets, and a recent-transactions table.
- **Transactions** — full table view with category badges, accounts, dates and tabular amounts; filter + add actions.
- **CoachPanel** — the always-on coach rail: conversation, an embedded budget card, prompt suggestions, send bar.
- **Shell** — `Sidebar` + `TopBar`.

## Run it
Open `index.html`. The sidebar switches **Overview / Transactions / Budgets / Goals**; the Coach rail is always present.

## Components used
`BalanceCard, StatCard, TransactionRow, BudgetBar, CoachMessage, CoachSuggestion, SearchInput, SegmentedControl, Button, IconButton, Avatar, Badge, IconChip, Icon`.

Design width **1320px**; scales to fit.
