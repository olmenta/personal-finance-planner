/* Olmenta web — Overview dashboard content. */
const {
  BalanceCard, StatCard, TransactionRow, BudgetBar, Badge, Icon, IconChip, Button,
} = window.OlmentaDesignSystem_4bdf9c;

function Panel({ title, action, children, style }) {
  return (
    <section style={{ background: "var(--surface)", border: "1px solid var(--border-hairline)", borderRadius: "var(--r-xl)", padding: 22, boxShadow: "var(--shadow-sm)", ...style }}>
      {title && (
        <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginBottom: 18 }}>
          <h2 style={{ font: "700 17px var(--font-sans)", letterSpacing: "-0.3px", color: "var(--text-strong)" }}>{title}</h2>
          {action}
        </div>
      )}
      {children}
    </section>
  );
}

function SpendChart() {
  const weeks = [
    { l: "W1", a: 62, b: 38 }, { l: "W2", a: 80, b: 52 }, { l: "W3", a: 48, b: 30 },
    { l: "W4", a: 92, b: 60 }, { l: "W5", a: 70, b: 44 },
  ];
  return (
    <Panel title="Spending this month" action={<div style={{ display: "flex", gap: 14 }}>
      <span style={{ display: "flex", alignItems: "center", gap: 6, font: "500 12px var(--font-sans)", color: "var(--text-muted)" }}><span style={{ width: 10, height: 10, borderRadius: 3, background: "var(--violet-500)" }} /> Spent</span>
      <span style={{ display: "flex", alignItems: "center", gap: 6, font: "500 12px var(--font-sans)", color: "var(--text-muted)" }}><span style={{ width: 10, height: 10, borderRadius: 3, background: "var(--mint-400)" }} /> Saved</span>
    </div>}>
      <div style={{ display: "flex", alignItems: "flex-end", justifyContent: "space-between", gap: 18, height: 180, padding: "0 4px" }}>
        {weeks.map((w) => (
          <div key={w.l} style={{ flex: 1, display: "flex", flexDirection: "column", alignItems: "center", gap: 10 }}>
            <div style={{ display: "flex", alignItems: "flex-end", gap: 6, height: 150, width: "100%", justifyContent: "center" }}>
              <div style={{ width: 14, height: `${w.a}%`, background: "var(--grad-balance)", borderRadius: "6px 6px 3px 3px" }} />
              <div style={{ width: 14, height: `${w.b}%`, background: "var(--mint-300)", borderRadius: "6px 6px 3px 3px" }} />
            </div>
            <span style={{ font: "600 12px var(--font-sans)", color: "var(--text-subtle)" }}>{w.l}</span>
          </div>
        ))}
      </div>
    </Panel>
  );
}

function Dashboard() {
  return (
    <div style={{ padding: 28, display: "flex", flexDirection: "column", gap: 20 }}>
      {/* Row 1 */}
      <div style={{ display: "grid", gridTemplateColumns: "1.5fr 1fr 1fr", gap: 20 }}>
        <BalanceCard label="Current balance" amount="$87,457" cents=".85" delta="↑ $784 than last week" align="left" style={{ borderRadius: "var(--r-xl)" }} />
        <StatCard icon="trending-up" tone="income" label="Income" value="$4,875.12" />
        <StatCard icon="trending-down" tone="expense" label="Expenses" value="$8,145.78" />
      </div>

      {/* Row 2 */}
      <div style={{ display: "grid", gridTemplateColumns: "1.5fr 1fr", gap: 20 }}>
        <SpendChart />
        <Panel title="Budgets" action={<Badge tone="brand">4 active</Badge>}>
          <div style={{ display: "flex", flexDirection: "column", gap: 17 }}>
            <BudgetBar icon="shopping-bag" tone="violet" label="Shopping" spent="$13,058" limit="$15,000" />
            <BudgetBar icon="receipt" tone="info" label="Bills" spent="$10,109" limit="$10,000" />
            <BudgetBar icon="coffee" tone="mint" label="Food & dining" spent="$8,846" limit="$12,000" />
            <BudgetBar icon="plane" tone="warning" label="Travel" spent="$5,897" limit="$8,000" />
          </div>
        </Panel>
      </div>

      {/* Row 3 */}
      <Panel title="Recent transactions" action={<Button variant="ghost" size="sm" iconRight="chevron-right">View all</Button>}>
        <div style={{ display: "flex", flexDirection: "column" }}>
          {[
            { icon: "wallet", tone: "violet", title: "Cash withdrawal", subtitle: "Red Card · 12 Jan", amount: "354.25", direction: "out" },
            { icon: "dollar-sign", tone: "income", title: "Salary", subtitle: "Main account · 10 Jan", amount: "4,875.12", direction: "in" },
            { icon: "coffee", tone: "info", title: "Blue Bottle Coffee", subtitle: "Food & dining · 9 Jan", amount: "12.49", direction: "out" },
            { icon: "shopping-bag", tone: "violet", title: "Apple Store", subtitle: "Shopping · 8 Jan", amount: "129.00", direction: "out" },
          ].map((t, i) => (
            <div key={i} style={{ borderBottom: i < 3 ? "1px solid var(--border-hairline)" : "none" }}>
              <TransactionRow {...t} card={false} />
            </div>
          ))}
        </div>
      </Panel>
    </div>
  );
}

Object.assign(window, { Dashboard, Panel });
