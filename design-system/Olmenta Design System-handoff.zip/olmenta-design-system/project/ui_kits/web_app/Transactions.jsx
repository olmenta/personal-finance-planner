/* Olmenta web — Transactions table view. */
const { TransactionRow, Badge, Button, Icon, SegmentedControl, IconChip } = window.OlmentaDesignSystem_4bdf9c;

function TxTable({ rows }) {
  return (
    <div>
      <div style={{ display: "grid", gridTemplateColumns: "2fr 1.2fr 1fr 0.9fr", gap: 16, padding: "0 6px 12px", borderBottom: "1px solid var(--border-hairline)" }}>
        {["Transaction", "Category", "Date", "Amount"].map((h, i) => (
          <span key={h} style={{ font: "var(--t-eyebrow-fw) var(--t-eyebrow-size)/1 var(--font-sans)", letterSpacing: "var(--t-eyebrow-ls)", textTransform: "uppercase", color: "var(--text-subtle)", textAlign: i === 3 ? "right" : "left" }}>{h}</span>
        ))}
      </div>
      {rows.map((r, i) => (
        <div key={i} style={{ display: "grid", gridTemplateColumns: "2fr 1.2fr 1fr 0.9fr", gap: 16, alignItems: "center", padding: "13px 6px", borderBottom: i < rows.length - 1 ? "1px solid var(--border-hairline)" : "none" }}>
          <div style={{ display: "flex", alignItems: "center", gap: 12 }}>
            <IconChip icon={r.icon} tone={r.tone} size={40} />
            <div>
              <div style={{ font: "600 14.5px var(--font-sans)", color: "var(--text-strong)", letterSpacing: "-0.1px" }}>{r.title}</div>
              <div style={{ font: "500 12px var(--font-mono)", color: "var(--text-subtle)" }}>{r.acct}</div>
            </div>
          </div>
          <div><Badge tone={r.badgeTone || "neutral"} dot>{r.cat}</Badge></div>
          <div style={{ font: "500 13.5px var(--font-sans)", color: "var(--text-muted)" }}>{r.date}</div>
          <div style={{ textAlign: "right", font: "700 14.5px var(--font-sans)", fontVariantNumeric: "tabular-nums", color: r.direction === "in" ? "var(--income)" : "var(--text-strong)" }}>
            {r.direction === "in" ? "+" : "−"}{r.amount}
          </div>
        </div>
      ))}
    </div>
  );
}

function Transactions() {
  const rows = [
    { icon: "dollar-sign", tone: "income", title: "Salary", acct: "•••• 4821", cat: "Income", badgeTone: "income", date: "10 Jan 2026", amount: "$4,875.12", direction: "in" },
    { icon: "wallet", tone: "violet", title: "Cash withdrawal", acct: "Red Card", cat: "Transfer", badgeTone: "brand", date: "12 Jan 2026", amount: "$354.25", direction: "out" },
    { icon: "shopping-bag", tone: "violet", title: "Apple Store", acct: "•••• 0934", cat: "Shopping", badgeTone: "brand", date: "8 Jan 2026", amount: "$129.00", direction: "out" },
    { icon: "coffee", tone: "info", title: "Blue Bottle Coffee", acct: "•••• 0934", cat: "Food", badgeTone: "info", date: "9 Jan 2026", amount: "$12.49", direction: "out" },
    { icon: "plane", tone: "warning", title: "United Airlines", acct: "•••• 0934", cat: "Travel", badgeTone: "warning", date: "5 Jan 2026", amount: "$642.00", direction: "out" },
    { icon: "receipt", tone: "mint", title: "Con Edison", acct: "Auto-pay", cat: "Bills", badgeTone: "mint", date: "3 Jan 2026", amount: "$214.30", direction: "out" },
  ];
  return (
    <div style={{ padding: 28, display: "flex", flexDirection: "column", gap: 20 }}>
      <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between" }}>
        <div style={{ width: 320 }}>
          <SegmentedControl options={["All", "Expenses", "Income"]} defaultValue="All" />
        </div>
        <div style={{ display: "flex", gap: 10 }}>
          <Button variant="ghost" size="sm" iconLeft="filter">Filter</Button>
          <Button variant="primary" size="sm" iconLeft="plus">Add transaction</Button>
        </div>
      </div>
      <section style={{ background: "var(--surface)", border: "1px solid var(--border-hairline)", borderRadius: "var(--r-xl)", padding: 22, boxShadow: "var(--shadow-sm)" }}>
        <TxTable rows={rows} />
      </section>
    </div>
  );
}

Object.assign(window, { Transactions });
