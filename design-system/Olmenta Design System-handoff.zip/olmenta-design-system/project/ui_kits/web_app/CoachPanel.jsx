/* Olmenta web — persistent Coach rail on the right of the dashboard. */
const {
  CoachMessage, CoachSuggestion, IconButton, Icon, BudgetBar, Button, Badge,
} = window.OlmentaDesignSystem_4bdf9c;

function CoachPanel() {
  const [draft, setDraft] = React.useState("");
  return (
    <aside style={{ width: 360, flex: "none", background: "var(--surface)", borderLeft: "1px solid var(--border-hairline)", display: "flex", flexDirection: "column", height: "100%" }}>
      <div style={{ display: "flex", alignItems: "center", gap: 12, padding: "20px 20px", borderBottom: "1px solid var(--border-hairline)" }}>
        <span style={{ width: 40, height: 40, borderRadius: 999, background: "var(--grad-coach)", display: "flex", alignItems: "center", justifyContent: "center", flex: "none" }}>
          <Icon name="sparkles" size={19} color="var(--mint-400)" />
        </span>
        <div style={{ flex: 1 }}>
          <div style={{ font: "700 16px var(--font-sans)", letterSpacing: "-0.3px", color: "var(--text-strong)" }}>Coach</div>
          <div style={{ display: "flex", alignItems: "center", gap: 5, font: "500 12px var(--font-sans)", color: "var(--mint-600)" }}>
            <span style={{ width: 7, height: 7, borderRadius: 999, background: "var(--mint-500)" }} /> Watching your money
          </div>
        </div>
        <IconButton icon="more-horizontal" variant="ghost" size="sm" ariaLabel="More" />
      </div>

      <div style={{ flex: 1, overflowY: "auto", padding: "20px 18px", display: "flex", flexDirection: "column", gap: 14 }}>
        <CoachMessage role="coach">Your dining spend is up <b>18%</b> this month — mostly weekend cafés.</CoachMessage>
        <CoachMessage role="coach">
          <div style={{ marginBottom: 10 }}>Food &amp; dining vs budget:</div>
          <div style={{ background: "var(--bg)", borderRadius: "var(--r-md)", padding: 12 }}>
            <BudgetBar icon="coffee" tone="warning" label="Food & dining" spent="$8,846" limit="$9,000" />
          </div>
        </CoachMessage>
        <CoachMessage role="user">Can you cap it?</CoachMessage>
        <CoachMessage role="coach">Setting a <b>$300 weekly cap</b>. You're still on track for Japan 🎌</CoachMessage>
        <div style={{ paddingLeft: 40 }}>
          <Button variant="accent" size="sm" iconLeft="check">Set the $300 cap</Button>
        </div>
      </div>

      <div style={{ flex: "none", padding: "12px 16px 16px", borderTop: "1px solid var(--border-hairline)" }}>
        <div style={{ marginBottom: 12 }}>
          <CoachSuggestion suggestions={[{ label: "Where can I cut back?", icon: "trending-down" }, { label: "On track for Japan?", icon: "plane" }]} onPick={setDraft} />
        </div>
        <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
          <span style={{ flex: 1, display: "flex", alignItems: "center", gap: 9, background: "var(--surface-sunk)", borderRadius: 999, padding: "0 16px", height: 46 }}>
            <input value={draft} onChange={(e) => setDraft(e.target.value)} placeholder="Ask the coach…" style={{ flex: 1, border: "none", outline: "none", background: "transparent", font: "500 14.5px var(--font-sans)", color: "var(--text-strong)", minWidth: 0 }} />
          </span>
          <IconButton icon="send" variant="fab" size="md" ariaLabel="Send" />
        </div>
      </div>
    </aside>
  );
}

Object.assign(window, { CoachPanel });
