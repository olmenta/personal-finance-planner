/* @ds-bundle: {"format":3,"namespace":"OlmentaDesignSystem_4bdf9c","components":[{"name":"CoachCapsule","sourcePath":"components/coach/CoachCapsule.jsx"},{"name":"CoachMessage","sourcePath":"components/coach/CoachMessage.jsx"},{"name":"CoachSuggestion","sourcePath":"components/coach/CoachSuggestion.jsx"},{"name":"Avatar","sourcePath":"components/core/Avatar.jsx"},{"name":"Badge","sourcePath":"components/core/Badge.jsx"},{"name":"Button","sourcePath":"components/core/Button.jsx"},{"name":"Icon","sourcePath":"components/core/Icon.jsx"},{"name":"OLMENTA_ICON_NAMES","sourcePath":"components/core/Icon.jsx"},{"name":"IconButton","sourcePath":"components/core/IconButton.jsx"},{"name":"SegmentedControl","sourcePath":"components/core/SegmentedControl.jsx"},{"name":"Switch","sourcePath":"components/core/Switch.jsx"},{"name":"BalanceCard","sourcePath":"components/finance/BalanceCard.jsx"},{"name":"BudgetBar","sourcePath":"components/finance/BudgetBar.jsx"},{"name":"IconChip","sourcePath":"components/finance/IconChip.jsx"},{"name":"StatCard","sourcePath":"components/finance/StatCard.jsx"},{"name":"TransactionRow","sourcePath":"components/finance/TransactionRow.jsx"},{"name":"Input","sourcePath":"components/forms/Input.jsx"},{"name":"SearchInput","sourcePath":"components/forms/SearchInput.jsx"}],"sourceHashes":{"components/coach/CoachCapsule.jsx":"ba5aa056155d","components/coach/CoachMessage.jsx":"b5e4481de6d3","components/coach/CoachSuggestion.jsx":"d5ef0e7aeb42","components/core/Avatar.jsx":"f48e1d44b486","components/core/Badge.jsx":"e7296d2ad11a","components/core/Button.jsx":"4845b23e0a83","components/core/Icon.jsx":"2047dd407ee1","components/core/IconButton.jsx":"5ea6bec774b0","components/core/SegmentedControl.jsx":"4c2e4e0aa5d7","components/core/Switch.jsx":"bb320fb79e81","components/finance/BalanceCard.jsx":"36b0d2114ad1","components/finance/BudgetBar.jsx":"0270cfbb0d49","components/finance/IconChip.jsx":"009fba3a5adf","components/finance/StatCard.jsx":"be991e41eb6d","components/finance/TransactionRow.jsx":"6d2f91df8344","components/forms/Input.jsx":"3eaef6473ec0","components/forms/SearchInput.jsx":"5bcfc4c40171","ui_kits/mobile_app/Chrome.jsx":"5521de37b237","ui_kits/mobile_app/CoachScreen.jsx":"294245f34b16","ui_kits/mobile_app/HomeScreen.jsx":"38ea5bb78234","ui_kits/mobile_app/ReportScreen.jsx":"f62ac15ef90e","ui_kits/mobile_app/SettingsScreen.jsx":"538c07188fdd","ui_kits/web_app/CoachPanel.jsx":"76cd41ee9745","ui_kits/web_app/Dashboard.jsx":"1bb8cfe51406","ui_kits/web_app/Shell.jsx":"785c8242d9f0","ui_kits/web_app/Transactions.jsx":"0730b5a7d0ad"},"inlinedExternals":[],"unexposedExports":[]} */

(() => {

const __ds_ns = (window.OlmentaDesignSystem_4bdf9c = window.OlmentaDesignSystem_4bdf9c || {});

const __ds_scope = {};

(__ds_ns.__errors = __ds_ns.__errors || []);

// components/core/Avatar.jsx
try { (() => {
/**
 * Avatar with image or initials fallback. Optional status ring (coach = mint)
 * and a small badge slot bottom-right (e.g. a wallet glyph).
 */
function Avatar({
  src,
  name = "",
  size = 44,
  ring = "none",
  badge,
  style
}) {
  const initials = name.split(" ").filter(Boolean).slice(0, 2).map(w => w[0]).join("").toUpperCase();
  const rings = {
    none: "none",
    brand: "0 0 0 2.5px var(--surface), 0 0 0 4.5px var(--brand)",
    mint: "0 0 0 2.5px var(--surface), 0 0 0 4.5px var(--accent)"
  };
  return /*#__PURE__*/React.createElement("span", {
    style: {
      position: "relative",
      display: "inline-flex",
      flex: "none",
      ...style
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      width: size,
      height: size,
      borderRadius: "var(--r-full)",
      overflow: "hidden",
      display: "flex",
      alignItems: "center",
      justifyContent: "center",
      background: src ? "var(--gray-100)" : "var(--violet-100)",
      color: "var(--violet-700)",
      fontFamily: "var(--font-sans)",
      fontWeight: 700,
      fontSize: size * 0.36,
      letterSpacing: "-0.3px",
      boxShadow: rings[ring] || rings.none
    }
  }, src ? /*#__PURE__*/React.createElement("img", {
    src: src,
    alt: name,
    style: {
      width: "100%",
      height: "100%",
      objectFit: "cover"
    }
  }) : initials || "?"), badge && /*#__PURE__*/React.createElement("span", {
    style: {
      position: "absolute",
      right: -2,
      bottom: -2,
      width: size * 0.42,
      height: size * 0.42,
      borderRadius: "var(--r-full)",
      background: "var(--accent)",
      color: "#fff",
      display: "flex",
      alignItems: "center",
      justifyContent: "center",
      border: "2px solid var(--surface)"
    }
  }, badge));
}
Object.assign(__ds_scope, { Avatar });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Avatar.jsx", error: String((e && e.message) || e) }); }

// components/core/Icon.jsx
try { (() => {
/* Lucide icon path data (stroke, 24×24) copied for self-contained rendering.
   github.com/lucide-icons/lucide · ISC license. */
const OL_ICONS = {
  home: '<path d="m3 9 9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"/><path d="M9 22V12h6v10"/>',
  wallet: '<path d="M21 12V7H5a2 2 0 0 1 0-4h14v4"/><path d="M3 5v14a2 2 0 0 0 2 2h16v-5"/><path d="M18 12a2 2 0 0 0 0 4h4v-4Z"/>',
  "pie-chart": '<path d="M21.21 15.89A10 10 0 1 1 8 2.83"/><path d="M22 12A10 10 0 0 0 12 2v10z"/>',
  "bar-chart": '<path d="M3 3v16a2 2 0 0 0 2 2h16"/><path d="M18 17V9"/><path d="M13 17V5"/><path d="M8 17v-3"/>',
  dashboard: '<rect width="7" height="9" x="3" y="3" rx="1"/><rect width="7" height="5" x="14" y="3" rx="1"/><rect width="7" height="9" x="14" y="12" rx="1"/><rect width="7" height="5" x="3" y="16" rx="1"/>',
  settings: '<path d="M12.22 2h-.44a2 2 0 0 0-2 2v.18a2 2 0 0 1-1 1.73l-.43.25a2 2 0 0 1-2 0l-.15-.08a2 2 0 0 0-2.73.73l-.22.38a2 2 0 0 0 .73 2.73l.15.1a2 2 0 0 1 1 1.72v.51a2 2 0 0 1-1 1.74l-.15.09a2 2 0 0 0-.73 2.73l.22.38a2 2 0 0 0 2.73.73l.15-.08a2 2 0 0 1 2 0l.43.25a2 2 0 0 1 1 1.73V20a2 2 0 0 0 2 2h.44a2 2 0 0 0 2-2v-.18a2 2 0 0 1 1-1.73l.43-.25a2 2 0 0 1 2 0l.15.08a2 2 0 0 0 2.73-.73l.22-.39a2 2 0 0 0-.73-2.73l-.15-.08a2 2 0 0 1-1-1.74v-.5a2 2 0 0 1 1-1.74l.15-.09a2 2 0 0 0 .73-2.73l-.22-.38a2 2 0 0 0-2.73-.73l-.15.08a2 2 0 0 1-2 0l-.43-.25a2 2 0 0 1-1-1.73V4a2 2 0 0 0-2-2z"/><circle cx="12" cy="12" r="3"/>',
  plus: '<path d="M5 12h14"/><path d="M12 5v14"/>',
  sparkles: '<path d="M9.937 15.5A2 2 0 0 0 8.5 14.063l-6.135-1.582a.5.5 0 0 1 0-.962L8.5 9.936A2 2 0 0 0 9.937 8.5l1.582-6.135a.5.5 0 0 1 .963 0L14.063 8.5A2 2 0 0 0 15.5 9.937l6.135 1.581a.5.5 0 0 1 0 .964L15.5 14.063a2 2 0 0 0-1.437 1.437l-1.582 6.135a.5.5 0 0 1-.963 0z"/><path d="M20 3v4"/><path d="M22 5h-4"/><path d="M4 17v2"/><path d="M5 18H3"/>',
  bell: '<path d="M10.268 21a2 2 0 0 0 3.464 0"/><path d="M3.262 15.326A1 1 0 0 0 4 17h16a1 1 0 0 0 .74-1.673C19.41 13.956 18 12.499 18 8A6 6 0 0 0 6 8c0 4.499-1.411 5.956-2.738 7.326"/>',
  "chevron-down": '<path d="m6 9 6 6 6-6"/>',
  "chevron-right": '<path d="m9 18 6-6-6-6"/>',
  "chevron-left": '<path d="m15 18-6-6 6-6"/>',
  "arrow-left": '<path d="m12 19-7-7 7-7"/><path d="M19 12H5"/>',
  "arrow-right": '<path d="M5 12h14"/><path d="m12 5 7 7-7 7"/>',
  "arrow-up-right": '<path d="M7 7h10v10"/><path d="M7 17 17 7"/>',
  "arrow-down-left": '<path d="M17 7 7 17"/><path d="M17 17H7V7"/>',
  "trending-up": '<path d="M16 7h6v6"/><path d="m22 7-8.5 8.5-5-5L2 17"/>',
  "trending-down": '<path d="M16 17h6v-6"/><path d="m22 17-8.5-8.5-5 5L2 7"/>',
  coffee: '<path d="M10 2v2"/><path d="M14 2v2"/><path d="M16 8a1 1 0 0 1 1 1v8a4 4 0 0 1-4 4H7a4 4 0 0 1-4-4V9a1 1 0 0 1 1-1h14a4 4 0 1 1 0 8h-1"/><path d="M6 2v2"/>',
  "shopping-bag": '<path d="M6 2 3 6v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2V6l-3-4z"/><path d="M3 6h18"/><path d="M16 10a4 4 0 0 1-8 0"/>',
  "credit-card": '<rect width="20" height="14" x="2" y="5" rx="2"/><path d="M2 10h20"/>',
  plane: '<path d="M17.8 19.2 16 11l3.5-3.5C21 6 21.5 4 21 3c-1-.5-3 0-4.5 1.5L13 8 4.8 6.2c-.5-.1-.9.1-1.1.5l-.3.5c-.2.5-.1 1 .3 1.3L9 12l-2 3H4l-1 1 3 2 2 3 1-1v-3l3-2 3.5 5.3c.3.4.8.5 1.3.3l.5-.2c.4-.3.6-.7.5-1.2z"/>',
  receipt: '<path d="M4 2v20l2-1 2 1 2-1 2 1 2-1 2 1 2-1 2 1V2l-2 1-2-1-2 1-2-1-2 1-2-1-2 1Z"/><path d="M16 8h-6a2 2 0 1 0 0 4h4a2 2 0 1 1 0 4H8"/><path d="M12 17.5v-11"/>',
  target: '<circle cx="12" cy="12" r="10"/><circle cx="12" cy="12" r="6"/><circle cx="12" cy="12" r="2"/>',
  home2: '<path d="M15 21v-8a1 1 0 0 0-1-1h-4a1 1 0 0 0-1 1v8"/><path d="M3 10a2 2 0 0 1 .709-1.528l7-5.999a2 2 0 0 1 2.582 0l7 5.999A2 2 0 0 1 21 10v9a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"/>',
  user: '<path d="M19 21v-2a4 4 0 0 0-4-4H9a4 4 0 0 0-4 4v2"/><circle cx="12" cy="7" r="4"/>',
  users: '<path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M22 21v-2a4 4 0 0 0-3-3.87"/><path d="M16 3.13a4 4 0 0 1 0 7.75"/>',
  send: '<path d="M14.536 21.686a.5.5 0 0 0 .937-.024l6.5-19a.496.496 0 0 0-.635-.635l-19 6.5a.5.5 0 0 0-.024.937l7.93 3.18a2 2 0 0 1 1.112 1.11z"/><path d="m21.854 2.147-10.94 10.939"/>',
  search: '<circle cx="11" cy="11" r="8"/><path d="m21 21-4.3-4.3"/>',
  check: '<path d="M20 6 9 17l-5-5"/>',
  x: '<path d="M18 6 6 18"/><path d="m6 6 12 12"/>',
  "more-horizontal": '<circle cx="12" cy="12" r="1"/><circle cx="19" cy="12" r="1"/><circle cx="5" cy="12" r="1"/>',
  info: '<circle cx="12" cy="12" r="10"/><path d="M12 16v-4"/><path d="M12 8h.01"/>',
  lock: '<rect width="18" height="11" x="3" y="11" rx="2" ry="2"/><path d="M7 11V7a5 5 0 0 1 10 0v4"/>',
  eye: '<path d="M2.062 12.348a1 1 0 0 1 0-.696 10.75 10.75 0 0 1 19.876 0 1 1 0 0 1 0 .696 10.75 10.75 0 0 1-19.876 0"/><circle cx="12" cy="12" r="3"/>',
  "eye-off": '<path d="M10.733 5.076a10.744 10.744 0 0 1 11.205 6.575 1 1 0 0 1 0 .696 10.747 10.747 0 0 1-1.444 2.49"/><path d="M14.084 14.158a3 3 0 0 1-4.242-4.242"/><path d="M17.479 17.499a10.75 10.75 0 0 1-15.417-5.151 1 1 0 0 1 0-.696 10.75 10.75 0 0 1 4.446-5.143"/><path d="m2 2 20 20"/>',
  calendar: '<path d="M8 2v4"/><path d="M16 2v4"/><rect width="18" height="18" x="3" y="4" rx="2"/><path d="M3 10h18"/>',
  "log-out": '<path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4"/><path d="m16 17 5-5-5-5"/><path d="M21 12H9"/>',
  flame: '<path d="M8.5 14.5A2.5 2.5 0 0 0 11 12c0-1.38-.5-2-1-3-1.072-2.143-.224-4.054 2-6 .5 2.5 2 4.9 4 6.5 2 1.6 3 3.5 3 5.5a7 7 0 1 1-14 0c0-1.153.433-2.294 1-3a2.5 2.5 0 0 0 2.5 2.5z"/>',
  zap: '<path d="M4 14a1 1 0 0 1-.78-1.63l9.9-10.2a.5.5 0 0 1 .86.46l-1.92 6.02A1 1 0 0 0 13 10h7a1 1 0 0 1 .78 1.63l-9.9 10.2a.5.5 0 0 1-.86-.46l1.92-6.02A1 1 0 0 0 11 14z"/>',
  "piggy-bank": '<path d="M11 17h3v2a1 1 0 0 0 1 1h2a1 1 0 0 0 1-1v-3a3.16 3.16 0 0 0 2-2h1a1 1 0 0 0 1-1v-2a1 1 0 0 0-1-1h-1a5 5 0 0 0-2-3V4a1 1 0 0 0-1-1 2 2 0 0 0-2 2c-.214 0-.427.015-.64.044"/><path d="M16 10h.01"/><path d="M2 8v1a2 2 0 0 0 2 2h1"/>',
  building: '<rect width="16" height="20" x="4" y="2" rx="2"/><path d="M9 22v-4h6v4"/><path d="M8 6h.01"/><path d="M16 6h.01"/><path d="M12 6h.01"/><path d="M12 10h.01"/><path d="M12 14h.01"/><path d="M16 10h.01"/><path d="M16 14h.01"/><path d="M8 10h.01"/><path d="M8 14h.01"/>',
  "dollar-sign": '<line x1="12" x2="12" y1="2" y2="22"/><path d="M17 5H9.5a3.5 3.5 0 0 0 0 7h5a3.5 3.5 0 0 1 0 7H6"/>',
  filter: '<polygon points="22 3 2 3 10 12.46 10 19 14 21 14 12.46 22 3"/>',
  pin: '<path d="M12 17v5"/><path d="M9 10.76a2 2 0 0 1-1.11 1.79l-1.78.9A2 2 0 0 0 5 15.24V16a1 1 0 0 0 1 1h12a1 1 0 0 0 1-1v-.76a2 2 0 0 0-1.11-1.79l-1.78-.9A2 2 0 0 1 15 10.76V7a1 1 0 0 1 1-1 2 2 0 0 0 0-4H8a2 2 0 0 0 0 4 1 1 0 0 1 1 1z"/>',
  clock: '<circle cx="12" cy="12" r="10"/><polyline points="12 6 12 12 16 14"/>',
  "arrow-up": '<path d="m5 12 7-7 7 7"/><path d="M12 19V5"/>',
  circle: '<circle cx="12" cy="12" r="10"/>'
};
function Icon({
  name,
  size = 20,
  strokeWidth = 2,
  color = "currentColor",
  className = "",
  style
}) {
  return /*#__PURE__*/React.createElement("svg", {
    className: className,
    width: size,
    height: size,
    viewBox: "0 0 24 24",
    fill: "none",
    stroke: color,
    strokeWidth: strokeWidth,
    strokeLinecap: "round",
    strokeLinejoin: "round",
    "aria-hidden": "true",
    style: style,
    dangerouslySetInnerHTML: {
      __html: OL_ICONS[name] || OL_ICONS.circle
    }
  });
}
const OLMENTA_ICON_NAMES = Object.keys(OL_ICONS);
Object.assign(__ds_scope, { Icon, OLMENTA_ICON_NAMES });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Icon.jsx", error: String((e && e.message) || e) }); }

// components/coach/CoachCapsule.jsx
try { (() => {
/**
 * The Coach capsule — Olmenta's signature dark "insight" banner. A sparkle
 * glyph, a short message, and a trailing CTA. This is the only dark capsule
 * surface in the product and marks the AI coach's voice.
 */
function CoachCapsule({
  message = "Your insight is ready",
  cta = "See it",
  onClick,
  accent = "mint",
  style
}) {
  const sparkColor = accent === "mint" ? "var(--mint-400)" : "var(--violet-300)";
  return /*#__PURE__*/React.createElement("div", {
    onClick: onClick,
    style: {
      display: "flex",
      alignItems: "center",
      justifyContent: "space-between",
      gap: 12,
      background: "var(--grad-coach)",
      color: "#fff",
      borderRadius: "var(--r-full)",
      padding: "12px 16px 12px 14px",
      boxShadow: "var(--shadow-coach)",
      cursor: onClick ? "pointer" : "default",
      ...style
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      display: "flex",
      alignItems: "center",
      gap: 11,
      minWidth: 0
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      width: 30,
      height: 30,
      flex: "none",
      borderRadius: "var(--r-sm)",
      background: "rgba(255,255,255,.1)",
      display: "flex",
      alignItems: "center",
      justifyContent: "center"
    }
  }, /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: "sparkles",
    size: 16,
    color: sparkColor,
    strokeWidth: 2
  })), /*#__PURE__*/React.createElement("span", {
    style: {
      font: "600 14.5px var(--font-sans)",
      letterSpacing: "-0.1px",
      whiteSpace: "nowrap",
      overflow: "hidden",
      textOverflow: "ellipsis"
    }
  }, message)), cta && /*#__PURE__*/React.createElement("span", {
    style: {
      display: "flex",
      alignItems: "center",
      gap: 3,
      font: "600 13.5px var(--font-sans)",
      color: "rgba(255,255,255,.85)",
      whiteSpace: "nowrap",
      flex: "none"
    }
  }, cta, /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: "chevron-right",
    size: 16
  })));
}
Object.assign(__ds_scope, { CoachCapsule });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/coach/CoachCapsule.jsx", error: String((e && e.message) || e) }); }

// components/coach/CoachMessage.jsx
try { (() => {
/**
 * A chat bubble in the Coach conversation. `role="coach"` renders a left-side
 * bubble led by a sparkle avatar; `role="user"` renders a right-aligned violet
 * bubble. Coach bubbles can carry rich children (cards, lists).
 */
function CoachMessage({
  role = "coach",
  children,
  style
}) {
  const isCoach = role === "coach";
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      gap: 10,
      alignItems: "flex-end",
      flexDirection: isCoach ? "row" : "row-reverse",
      ...style
    }
  }, isCoach && /*#__PURE__*/React.createElement("span", {
    style: {
      width: 30,
      height: 30,
      flex: "none",
      borderRadius: "var(--r-full)",
      background: "var(--grad-coach)",
      display: "flex",
      alignItems: "center",
      justifyContent: "center"
    }
  }, /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: "sparkles",
    size: 15,
    color: "var(--mint-400)",
    strokeWidth: 2
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      maxWidth: "78%",
      padding: "12px 15px",
      borderRadius: isCoach ? "4px 18px 18px 18px" : "18px 18px 4px 18px",
      background: isCoach ? "var(--surface)" : "var(--brand)",
      color: isCoach ? "var(--text-body)" : "#fff",
      border: isCoach ? "1px solid var(--border-hairline)" : "none",
      boxShadow: isCoach ? "var(--shadow-xs)" : "0 6px 16px rgba(124,92,252,.24)",
      font: "500 15px/1.5 var(--font-sans)",
      letterSpacing: "-0.1px"
    }
  }, children));
}
Object.assign(__ds_scope, { CoachMessage });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/coach/CoachMessage.jsx", error: String((e && e.message) || e) }); }

// components/coach/CoachSuggestion.jsx
try { (() => {
/**
 * Tappable suggestion chips that prompt the user with things to ask the coach.
 * Rendered as a wrapping row of ghost pills with a small leading glyph.
 */
function CoachSuggestion({
  suggestions = [],
  onPick,
  style
}) {
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      flexWrap: "wrap",
      gap: 8,
      ...style
    }
  }, suggestions.map((s, i) => {
    const label = typeof s === "string" ? s : s.label;
    const icon = typeof s === "string" ? "sparkles" : s.icon || "sparkles";
    return /*#__PURE__*/React.createElement("button", {
      key: i,
      type: "button",
      onClick: () => onPick && onPick(label),
      style: {
        display: "inline-flex",
        alignItems: "center",
        gap: 7,
        background: "var(--surface)",
        border: "1px solid var(--border-hairline)",
        borderRadius: "var(--r-full)",
        padding: "9px 14px",
        font: "600 13.5px var(--font-sans)",
        color: "var(--text-body)",
        cursor: "pointer",
        letterSpacing: "-0.1px",
        transition: "background var(--dur-base) var(--ease-out), border-color var(--dur-base) var(--ease-out)"
      },
      onMouseEnter: e => {
        e.currentTarget.style.background = "var(--violet-50)";
        e.currentTarget.style.borderColor = "var(--violet-200)";
      },
      onMouseLeave: e => {
        e.currentTarget.style.background = "var(--surface)";
        e.currentTarget.style.borderColor = "var(--border-hairline)";
      }
    }, /*#__PURE__*/React.createElement(__ds_scope.Icon, {
      name: icon,
      size: 14,
      color: "var(--violet-500)",
      strokeWidth: 2.25
    }), label);
  }));
}
Object.assign(__ds_scope, { CoachSuggestion });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/coach/CoachSuggestion.jsx", error: String((e && e.message) || e) }); }

// components/core/Badge.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * Compact status/label chip. Tones: brand, mint, income, expense, info,
 * warning, neutral, dark. `soft` (default) uses tinted fill; `solid` fills.
 */
function Badge({
  children,
  tone = "neutral",
  solid = false,
  icon,
  dot = false,
  style,
  ...rest
}) {
  const map = {
    brand: {
      soft: ["var(--violet-100)", "var(--violet-700)"],
      solid: ["var(--brand)", "#fff"],
      dotc: "var(--brand)"
    },
    mint: {
      soft: ["var(--mint-100)", "var(--mint-700)"],
      solid: ["var(--accent)", "#fff"],
      dotc: "var(--accent)"
    },
    income: {
      soft: ["var(--income-soft)", "#0E8B5A"],
      solid: ["var(--income)", "#fff"],
      dotc: "var(--income)"
    },
    expense: {
      soft: ["var(--expense-soft)", "#C42E1E"],
      solid: ["var(--expense)", "#fff"],
      dotc: "var(--expense)"
    },
    info: {
      soft: ["var(--info-soft)", "#1E6FA8"],
      solid: ["var(--info)", "#fff"],
      dotc: "var(--info)"
    },
    warning: {
      soft: ["var(--warning-soft)", "#A66A0A"],
      solid: ["var(--warning)", "#fff"],
      dotc: "var(--warning)"
    },
    neutral: {
      soft: ["var(--gray-100)", "var(--ink-700)"],
      solid: ["var(--ink-900)", "#fff"],
      dotc: "var(--gray-400)"
    },
    dark: {
      soft: ["var(--ink-900)", "#fff"],
      solid: ["var(--ink-900)", "#fff"],
      dotc: "#fff"
    }
  };
  const t = map[tone] || map.neutral;
  const [bg, fg] = solid ? t.solid : t.soft;
  return /*#__PURE__*/React.createElement("span", _extends({
    style: {
      display: "inline-flex",
      alignItems: "center",
      gap: 5,
      background: bg,
      color: fg,
      fontFamily: "var(--font-sans)",
      fontWeight: 600,
      fontSize: 12,
      lineHeight: 1,
      letterSpacing: "0.1px",
      padding: "5px 10px",
      borderRadius: "var(--r-full)",
      whiteSpace: "nowrap",
      ...style
    }
  }, rest), dot && /*#__PURE__*/React.createElement("span", {
    style: {
      width: 7,
      height: 7,
      borderRadius: "50%",
      background: t.dotc,
      flex: "none"
    }
  }), icon && /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: icon,
    size: 13,
    strokeWidth: 2.5
  }), children);
}
Object.assign(__ds_scope, { Badge });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Badge.jsx", error: String((e && e.message) || e) }); }

// components/core/Button.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * Olmenta Button. Pill-shaped, weight-600 label, springy press.
 * Variants: primary (violet) · accent (mint) · secondary (violet-soft) ·
 * ghost (hairline) · dark (ink). Sizes: sm · md · lg · block.
 */
function Button({
  children,
  variant = "primary",
  size = "md",
  iconLeft,
  iconRight,
  block = false,
  disabled = false,
  type = "button",
  onClick,
  style,
  ...rest
}) {
  const sizes = {
    sm: {
      padding: "8px 14px",
      fontSize: 13.5,
      gap: 6,
      icon: 16,
      radius: "var(--r-full)"
    },
    md: {
      padding: "11px 20px",
      fontSize: 15,
      gap: 8,
      icon: 18,
      radius: "var(--r-full)"
    },
    lg: {
      padding: "15px 26px",
      fontSize: 16.5,
      gap: 9,
      icon: 20,
      radius: "var(--r-full)"
    }
  };
  const s = sizes[size] || sizes.md;
  const variants = {
    primary: {
      background: "var(--brand)",
      color: "#fff",
      border: "1px solid transparent",
      boxShadow: "0 6px 16px rgba(124,92,252,.28)"
    },
    accent: {
      background: "var(--accent)",
      color: "#fff",
      border: "1px solid transparent",
      boxShadow: "0 6px 16px rgba(22,199,154,.28)"
    },
    secondary: {
      background: "var(--brand-soft)",
      color: "var(--violet-700)",
      border: "1px solid transparent",
      boxShadow: "none"
    },
    ghost: {
      background: "var(--surface)",
      color: "var(--text-strong)",
      border: "1px solid var(--border-hairline)",
      boxShadow: "var(--shadow-xs)"
    },
    dark: {
      background: "var(--ink-900)",
      color: "#fff",
      border: "1px solid transparent",
      boxShadow: "var(--shadow-md)"
    }
  };
  const v = variants[variant] || variants.primary;
  return /*#__PURE__*/React.createElement("button", _extends({
    type: type,
    disabled: disabled,
    onClick: onClick,
    style: {
      display: block ? "flex" : "inline-flex",
      width: block ? "100%" : "auto",
      alignItems: "center",
      justifyContent: "center",
      gap: s.gap,
      fontFamily: "var(--font-sans)",
      fontWeight: 600,
      fontSize: s.fontSize,
      letterSpacing: "-0.1px",
      lineHeight: 1,
      padding: s.padding,
      borderRadius: s.radius,
      cursor: disabled ? "not-allowed" : "pointer",
      opacity: disabled ? 0.45 : 1,
      transition: "transform var(--dur-fast) var(--ease-spring), background var(--dur-base) var(--ease-out), box-shadow var(--dur-base) var(--ease-out)",
      whiteSpace: "nowrap",
      ...v,
      ...style
    },
    onMouseDown: e => {
      if (!disabled) e.currentTarget.style.transform = "scale(0.97)";
    },
    onMouseUp: e => {
      e.currentTarget.style.transform = "scale(1)";
    },
    onMouseLeave: e => {
      e.currentTarget.style.transform = "scale(1)";
    }
  }, rest), iconLeft && /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: iconLeft,
    size: s.icon,
    strokeWidth: 2.25
  }), children, iconRight && /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: iconRight,
    size: s.icon,
    strokeWidth: 2.25
  }));
}
Object.assign(__ds_scope, { Button });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Button.jsx", error: String((e && e.message) || e) }); }

// components/core/IconButton.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * Square/circular icon-only button. Variants: soft (violet tint), ghost
 * (hairline), plain (bare), dark. The FAB is `variant="fab"` — the only
 * surface that carries the violet glow shadow.
 */
function IconButton({
  icon,
  variant = "ghost",
  size = "md",
  round = true,
  disabled = false,
  ariaLabel,
  onClick,
  style,
  ...rest
}) {
  const sizes = {
    sm: 34,
    md: 42,
    lg: 50,
    fab: 60
  };
  const iconSizes = {
    sm: 18,
    md: 20,
    lg: 22,
    fab: 26
  };
  const dim = sizes[size] || sizes.md;
  const variants = {
    soft: {
      background: "var(--brand-soft)",
      color: "var(--violet-700)",
      border: "1px solid transparent",
      boxShadow: "none"
    },
    ghost: {
      background: "var(--surface)",
      color: "var(--text-body)",
      border: "1px solid var(--border-hairline)",
      boxShadow: "var(--shadow-xs)"
    },
    plain: {
      background: "transparent",
      color: "var(--text-body)",
      border: "1px solid transparent",
      boxShadow: "none"
    },
    dark: {
      background: "var(--ink-900)",
      color: "#fff",
      border: "1px solid transparent",
      boxShadow: "var(--shadow-md)"
    },
    fab: {
      background: "var(--brand)",
      color: "#fff",
      border: "1px solid transparent",
      boxShadow: "var(--shadow-fab)"
    }
  };
  const v = variants[variant] || variants.ghost;
  const isFab = variant === "fab";
  const d = isFab ? sizes.fab : dim;
  return /*#__PURE__*/React.createElement("button", _extends({
    type: "button",
    "aria-label": ariaLabel,
    disabled: disabled,
    onClick: onClick,
    style: {
      display: "inline-flex",
      alignItems: "center",
      justifyContent: "center",
      width: d,
      height: d,
      flex: "none",
      borderRadius: round ? "var(--r-full)" : "var(--r-md)",
      cursor: disabled ? "not-allowed" : "pointer",
      opacity: disabled ? 0.45 : 1,
      transition: "transform var(--dur-fast) var(--ease-spring), background var(--dur-base) var(--ease-out)",
      ...v,
      ...style
    },
    onMouseDown: e => {
      if (!disabled) e.currentTarget.style.transform = "scale(0.94)";
    },
    onMouseUp: e => {
      e.currentTarget.style.transform = "scale(1)";
    },
    onMouseLeave: e => {
      e.currentTarget.style.transform = "scale(1)";
    }
  }, rest), /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: icon,
    size: isFab ? iconSizes.fab : iconSizes[size] || iconSizes.md,
    strokeWidth: 2.25
  }));
}
Object.assign(__ds_scope, { IconButton });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/IconButton.jsx", error: String((e && e.message) || e) }); }

// components/core/SegmentedControl.jsx
try { (() => {
/**
 * iOS-style segmented control. Controlled via `value`/`onChange`, or
 * uncontrolled with `defaultValue`. The active segment lifts on a white pill.
 */
function SegmentedControl({
  options = [],
  value,
  defaultValue,
  onChange,
  size = "md",
  style
}) {
  const [internal, setInternal] = React.useState(defaultValue ?? (options[0] && (options[0].value ?? options[0])));
  const current = value !== undefined ? value : internal;
  const pad = size === "sm" ? "8px 12px" : "11px 16px";
  const fs = size === "sm" ? 13 : 14.5;
  function pick(v) {
    if (value === undefined) setInternal(v);
    onChange && onChange(v);
  }
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      background: "var(--surface-sunk)",
      borderRadius: "var(--r-full)",
      padding: 4,
      gap: 2,
      width: "100%",
      ...style
    }
  }, options.map(opt => {
    const v = opt.value ?? opt;
    const label = opt.label ?? opt;
    const active = v === current;
    return /*#__PURE__*/React.createElement("button", {
      key: v,
      type: "button",
      onClick: () => pick(v),
      style: {
        flex: 1,
        border: "none",
        cursor: "pointer",
        fontFamily: "var(--font-sans)",
        fontWeight: 600,
        fontSize: fs,
        letterSpacing: "-0.1px",
        padding: pad,
        borderRadius: "var(--r-full)",
        background: active ? "var(--surface)" : "transparent",
        color: active ? "var(--text-strong)" : "var(--text-muted)",
        boxShadow: active ? "var(--shadow-sm)" : "none",
        transition: "background var(--dur-base) var(--ease-out), color var(--dur-base) var(--ease-out)"
      }
    }, label);
  }));
}
Object.assign(__ds_scope, { SegmentedControl });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/SegmentedControl.jsx", error: String((e && e.message) || e) }); }

// components/core/Switch.jsx
try { (() => {
/**
 * Toggle switch. Controlled (`checked`/`onChange`) or uncontrolled
 * (`defaultChecked`). On = violet; the knob springs across.
 */
function Switch({
  checked,
  defaultChecked = false,
  onChange,
  disabled = false,
  size = "md",
  style
}) {
  const [internal, setInternal] = React.useState(defaultChecked);
  const on = checked !== undefined ? checked : internal;
  const dims = size === "sm" ? {
    w: 40,
    h: 24,
    k: 18
  } : {
    w: 50,
    h: 30,
    k: 24
  };
  function toggle() {
    if (disabled) return;
    if (checked === undefined) setInternal(!on);
    onChange && onChange(!on);
  }
  return /*#__PURE__*/React.createElement("button", {
    type: "button",
    role: "switch",
    "aria-checked": on,
    disabled: disabled,
    onClick: toggle,
    style: {
      width: dims.w,
      height: dims.h,
      flex: "none",
      borderRadius: "var(--r-full)",
      background: on ? "var(--brand)" : "var(--gray-300)",
      border: "none",
      padding: 3,
      cursor: disabled ? "not-allowed" : "pointer",
      opacity: disabled ? 0.5 : 1,
      transition: "background var(--dur-base) var(--ease-out)",
      display: "flex",
      alignItems: "center",
      ...style
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      width: dims.k,
      height: dims.k,
      borderRadius: "50%",
      background: "#fff",
      boxShadow: "0 1px 3px rgba(20,19,26,.25)",
      transform: on ? `translateX(${dims.w - dims.k - 6}px)` : "translateX(0)",
      transition: "transform var(--dur-base) var(--ease-spring)"
    }
  }));
}
Object.assign(__ds_scope, { Switch });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Switch.jsx", error: String((e && e.message) || e) }); }

// components/finance/BalanceCard.jsx
try { (() => {
/**
 * Hero balance card — violet gradient, centered amount with dimmed cents,
 * and a soft delta pill. The defining surface of the Olmenta home screen.
 */
function BalanceCard({
  label = "Current balance",
  amount,
  cents,
  delta,
  deltaTone = "up",
  align = "center",
  style,
  children
}) {
  // amount: integer part string e.g. "87,457"; cents: ".85"
  const tones = {
    up: {
      bg: "rgba(255,255,255,.18)",
      color: "#fff"
    },
    down: {
      bg: "rgba(255,255,255,.18)",
      color: "#fff"
    }
  };
  const d = tones[deltaTone] || tones.up;
  return /*#__PURE__*/React.createElement("div", {
    style: {
      background: "var(--grad-balance)",
      borderRadius: "var(--r-2xl)",
      padding: "30px 28px 32px",
      color: "#fff",
      textAlign: align,
      position: "relative",
      overflow: "hidden",
      boxShadow: "0 18px 40px rgba(106,71,234,.32)",
      ...style
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      font: "500 14px var(--font-sans)",
      opacity: 0.85,
      letterSpacing: "0.1px"
    }
  }, label), /*#__PURE__*/React.createElement("div", {
    style: {
      font: "800 44px var(--font-sans)",
      letterSpacing: "-1.6px",
      lineHeight: 1.05,
      margin: "8px 0 14px",
      fontVariantNumeric: "tabular-nums"
    }
  }, amount, cents && /*#__PURE__*/React.createElement("span", {
    style: {
      opacity: 0.55
    }
  }, cents)), delta && /*#__PURE__*/React.createElement("span", {
    style: {
      display: "inline-flex",
      alignItems: "center",
      gap: 6,
      background: d.bg,
      color: d.color,
      backdropFilter: "blur(6px)",
      padding: "7px 14px",
      borderRadius: "var(--r-full)",
      font: "600 13px var(--font-sans)"
    }
  }, delta), children);
}
Object.assign(__ds_scope, { BalanceCard });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/finance/BalanceCard.jsx", error: String((e && e.message) || e) }); }

// components/finance/IconChip.jsx
try { (() => {
const TONES = {
  violet: ["var(--violet-100)", "var(--violet-600)"],
  mint: ["var(--mint-100)", "var(--mint-600)"],
  income: ["var(--income-soft)", "var(--income)"],
  expense: ["var(--expense-soft)", "var(--expense)"],
  info: ["var(--info-soft)", "var(--info)"],
  warning: ["var(--warning-soft)", "var(--warning)"],
  neutral: ["var(--gray-100)", "var(--ink-700)"]
};

/**
 * Category icon chip: a soft tinted square holding a full-color glyph.
 * The transaction's category decides the tone. This is the signature
 * money-list motif.
 */
function IconChip({
  icon,
  tone = "neutral",
  size = 46,
  shape = "rounded",
  style
}) {
  const [bg, fg] = TONES[tone] || TONES.neutral;
  const radius = shape === "circle" ? "var(--r-full)" : "var(--r-md)";
  return /*#__PURE__*/React.createElement("span", {
    style: {
      width: size,
      height: size,
      flex: "none",
      borderRadius: radius,
      background: bg,
      color: fg,
      display: "inline-flex",
      alignItems: "center",
      justifyContent: "center",
      ...style
    }
  }, /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: icon,
    size: size * 0.46,
    strokeWidth: 2.25
  }));
}
Object.assign(__ds_scope, { IconChip });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/finance/IconChip.jsx", error: String((e && e.message) || e) }); }

// components/finance/BudgetBar.jsx
try { (() => {
/**
 * Budget / category progress bar. Shows spent vs limit with a tinted track;
 * the fill turns to expense-red once over 100%.
 */
function BudgetBar({
  icon,
  tone = "violet",
  label,
  spent,
  limit,
  percent,
  style
}) {
  const pct = percent !== undefined ? percent : limit ? Math.round(spent / limit * 100) : 0;
  const over = pct > 100;
  const fillColor = over ? "var(--expense)" : `var(--${tone === "violet" ? "violet-500" : tone === "mint" ? "mint-500" : tone === "income" ? "income" : tone === "warning" ? "warning" : tone === "info" ? "info" : "violet-500"})`;
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      alignItems: "center",
      gap: 13,
      ...style
    }
  }, icon && /*#__PURE__*/React.createElement(__ds_scope.IconChip, {
    icon: icon,
    tone: over ? "expense" : tone,
    size: 40
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1,
      minWidth: 0
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      justifyContent: "space-between",
      alignItems: "baseline",
      marginBottom: 7
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      font: "600 14px var(--font-sans)",
      color: "var(--text-strong)",
      letterSpacing: "-0.1px"
    }
  }, label), /*#__PURE__*/React.createElement("span", {
    style: {
      font: "600 13px var(--font-sans)",
      color: over ? "var(--expense)" : "var(--text-muted)",
      fontVariantNumeric: "tabular-nums"
    }
  }, spent, limit ? /*#__PURE__*/React.createElement("span", {
    style: {
      color: "var(--text-subtle)",
      fontWeight: 500
    }
  }, " / ", limit) : null)), /*#__PURE__*/React.createElement("div", {
    style: {
      height: 8,
      borderRadius: "var(--r-full)",
      background: "var(--gray-100)",
      overflow: "hidden"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      width: `${Math.min(pct, 100)}%`,
      height: "100%",
      borderRadius: "var(--r-full)",
      background: fillColor,
      transition: "width var(--dur-slow) var(--ease-out)"
    }
  }))));
}
Object.assign(__ds_scope, { BudgetBar });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/finance/BudgetBar.jsx", error: String((e && e.message) || e) }); }

// components/finance/StatCard.jsx
try { (() => {
/**
 * Compact metric card — icon chip, label with info affordance, and a tabular
 * value. Used in the "Your money" income/expense pair.
 */
function StatCard({
  icon,
  tone = "income",
  label,
  value,
  info = true,
  style
}) {
  return /*#__PURE__*/React.createElement("div", {
    style: {
      background: "var(--surface)",
      border: "1px solid var(--border-hairline)",
      borderRadius: "var(--r-xl)",
      padding: 18,
      boxShadow: "var(--shadow-sm)",
      ...style
    }
  }, /*#__PURE__*/React.createElement(__ds_scope.IconChip, {
    icon: icon,
    tone: tone,
    size: 44
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      alignItems: "center",
      gap: 4,
      marginTop: 14
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      font: "500 13px var(--font-sans)",
      color: "var(--text-muted)"
    }
  }, label), info && /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: "info",
    size: 13,
    color: "var(--text-subtle)"
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      font: "700 22px var(--font-sans)",
      letterSpacing: "-0.5px",
      marginTop: 4,
      fontVariantNumeric: "tabular-nums",
      color: "var(--text-strong)"
    }
  }, value));
}
Object.assign(__ds_scope, { StatCard });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/finance/StatCard.jsx", error: String((e && e.message) || e) }); }

// components/finance/TransactionRow.jsx
try { (() => {
/**
 * One transaction line: category chip, title + sub-line, and a tabular amount
 * colored by direction (income green / expense red). Optional running balance.
 */
function TransactionRow({
  icon,
  tone = "neutral",
  title,
  subtitle,
  amount,
  direction = "out",
  balance,
  card = true,
  onClick,
  style
}) {
  const amtColor = direction === "in" ? "var(--income)" : direction === "out" ? "var(--expense)" : "var(--text-strong)";
  const sign = direction === "in" ? "+" : direction === "out" ? "-" : "";
  return /*#__PURE__*/React.createElement("div", {
    onClick: onClick,
    style: {
      display: "flex",
      alignItems: "center",
      gap: 13,
      background: card ? "var(--surface)" : "transparent",
      border: card ? "1px solid var(--border-hairline)" : "none",
      borderRadius: "var(--r-lg)",
      padding: card ? "13px 15px" : "10px 0",
      boxShadow: card ? "var(--shadow-xs)" : "none",
      cursor: onClick ? "pointer" : "default",
      ...style
    }
  }, /*#__PURE__*/React.createElement(__ds_scope.IconChip, {
    icon: icon,
    tone: tone,
    size: 44
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1,
      minWidth: 0
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      font: "600 15.5px var(--font-sans)",
      color: "var(--text-strong)",
      letterSpacing: "-0.2px",
      whiteSpace: "nowrap",
      overflow: "hidden",
      textOverflow: "ellipsis"
    }
  }, title), subtitle && /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      alignItems: "center",
      gap: 5,
      font: "500 12.5px var(--font-sans)",
      color: "var(--text-muted)",
      marginTop: 2
    }
  }, subtitle)), /*#__PURE__*/React.createElement("div", {
    style: {
      textAlign: "right",
      flex: "none"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      font: "700 15px var(--font-sans)",
      color: amtColor,
      fontVariantNumeric: "tabular-nums",
      letterSpacing: "-0.2px"
    }
  }, sign, amount), balance && /*#__PURE__*/React.createElement("div", {
    style: {
      font: "500 12px var(--font-sans)",
      color: "var(--text-subtle)",
      marginTop: 2,
      fontVariantNumeric: "tabular-nums"
    }
  }, balance)));
}
Object.assign(__ds_scope, { TransactionRow });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/finance/TransactionRow.jsx", error: String((e && e.message) || e) }); }

// components/forms/Input.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * Text input field with optional label, leading icon, prefix (e.g. "$"),
 * help/error text. Rounded, soft-well fill, violet focus ring.
 */
function Input({
  label,
  value,
  defaultValue,
  placeholder,
  type = "text",
  iconLeft,
  prefix,
  suffix,
  error,
  help,
  disabled = false,
  onChange,
  style,
  inputStyle,
  ...rest
}) {
  const [focus, setFocus] = React.useState(false);
  const borderColor = error ? "var(--expense)" : focus ? "var(--brand)" : "var(--border-hairline)";
  return /*#__PURE__*/React.createElement("label", {
    style: {
      display: "flex",
      flexDirection: "column",
      gap: 7,
      ...style
    }
  }, label && /*#__PURE__*/React.createElement("span", {
    style: {
      font: "600 13.5px var(--font-sans)",
      color: "var(--text-body)",
      letterSpacing: "-0.1px"
    }
  }, label), /*#__PURE__*/React.createElement("span", {
    style: {
      display: "flex",
      alignItems: "center",
      gap: 9,
      background: disabled ? "var(--gray-100)" : "var(--surface)",
      border: `1.5px solid ${borderColor}`,
      borderRadius: "var(--r-sm)",
      padding: "0 14px",
      height: 48,
      boxShadow: focus ? "var(--focus-ring)" : "none",
      transition: "border-color var(--dur-base) var(--ease-out), box-shadow var(--dur-base) var(--ease-out)"
    }
  }, iconLeft && /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: iconLeft,
    size: 18,
    color: "var(--text-subtle)"
  }), prefix && /*#__PURE__*/React.createElement("span", {
    style: {
      font: "700 16px var(--font-sans)",
      color: "var(--text-muted)"
    }
  }, prefix), /*#__PURE__*/React.createElement("input", _extends({
    type: type,
    value: value,
    defaultValue: defaultValue,
    placeholder: placeholder,
    disabled: disabled,
    onChange: onChange,
    onFocus: () => setFocus(true),
    onBlur: () => setFocus(false),
    style: {
      flex: 1,
      border: "none",
      outline: "none",
      background: "transparent",
      font: "500 16px var(--font-sans)",
      color: "var(--text-strong)",
      minWidth: 0,
      ...inputStyle
    }
  }, rest)), suffix && /*#__PURE__*/React.createElement("span", {
    style: {
      font: "600 14px var(--font-sans)",
      color: "var(--text-muted)"
    }
  }, suffix)), (error || help) && /*#__PURE__*/React.createElement("span", {
    style: {
      font: "500 12.5px var(--font-sans)",
      color: error ? "var(--expense)" : "var(--text-muted)"
    }
  }, error || help));
}
Object.assign(__ds_scope, { Input });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/Input.jsx", error: String((e && e.message) || e) }); }

// components/forms/SearchInput.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * Rounded search field for lists and transactions. Pill-shaped, sunk fill.
 */
function SearchInput({
  value,
  defaultValue,
  placeholder = "Search",
  onChange,
  size = "md",
  style,
  ...rest
}) {
  const h = size === "sm" ? 40 : 46;
  return /*#__PURE__*/React.createElement("span", {
    style: {
      display: "flex",
      alignItems: "center",
      gap: 9,
      background: "var(--surface-sunk)",
      border: "1px solid transparent",
      borderRadius: "var(--r-full)",
      padding: "0 16px",
      height: h,
      ...style
    }
  }, /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: "search",
    size: 18,
    color: "var(--text-subtle)"
  }), /*#__PURE__*/React.createElement("input", _extends({
    value: value,
    defaultValue: defaultValue,
    placeholder: placeholder,
    onChange: onChange,
    style: {
      flex: 1,
      border: "none",
      outline: "none",
      background: "transparent",
      font: "500 15px var(--font-sans)",
      color: "var(--text-strong)",
      minWidth: 0
    }
  }, rest)));
}
Object.assign(__ds_scope, { SearchInput });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/SearchInput.jsx", error: String((e && e.message) || e) }); }

// ui_kits/mobile_app/Chrome.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/* Mobile app chrome: iOS status bar, phone frame, and the pinned bottom nav. */
const {
  Icon,
  IconButton
} = window.OlmentaDesignSystem_4bdf9c;
function StatusBar({
  dark = false
}) {
  const color = dark ? "#fff" : "var(--ink-900)";
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      alignItems: "center",
      justifyContent: "space-between",
      padding: "14px 28px 6px",
      height: 44
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      font: "700 15px var(--font-sans)",
      color,
      letterSpacing: "0.2px"
    }
  }, "9:41"), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      alignItems: "center",
      gap: 6,
      color
    }
  }, /*#__PURE__*/React.createElement("svg", {
    width: "18",
    height: "12",
    viewBox: "0 0 18 12",
    fill: "none"
  }, /*#__PURE__*/React.createElement("rect", {
    x: "0",
    y: "7",
    width: "3",
    height: "5",
    rx: "1",
    fill: "currentColor"
  }), /*#__PURE__*/React.createElement("rect", {
    x: "5",
    y: "4.5",
    width: "3",
    height: "7.5",
    rx: "1",
    fill: "currentColor"
  }), /*#__PURE__*/React.createElement("rect", {
    x: "10",
    y: "2",
    width: "3",
    height: "10",
    rx: "1",
    fill: "currentColor"
  }), /*#__PURE__*/React.createElement("rect", {
    x: "15",
    y: "0",
    width: "3",
    height: "12",
    rx: "1",
    fill: "currentColor",
    opacity: "0.35"
  })), /*#__PURE__*/React.createElement("svg", {
    width: "17",
    height: "12",
    viewBox: "0 0 17 12",
    fill: "none"
  }, /*#__PURE__*/React.createElement("path", {
    d: "M8.5 2.5c2.3 0 4.4.9 6 2.4l-1.4 1.4a6.6 6.6 0 0 0-9.2 0L2.5 4.9A8.6 8.6 0 0 1 8.5 2.5Z",
    fill: "currentColor"
  }), /*#__PURE__*/React.createElement("path", {
    d: "M8.5 6.2c1.3 0 2.5.5 3.3 1.4l-3.3 3.3-3.3-3.3A4.6 4.6 0 0 1 8.5 6.2Z",
    fill: "currentColor"
  })), /*#__PURE__*/React.createElement("svg", {
    width: "26",
    height: "13",
    viewBox: "0 0 26 13",
    fill: "none"
  }, /*#__PURE__*/React.createElement("rect", {
    x: "0.5",
    y: "0.5",
    width: "22",
    height: "12",
    rx: "3.5",
    stroke: "currentColor",
    opacity: "0.4"
  }), /*#__PURE__*/React.createElement("rect", {
    x: "2",
    y: "2",
    width: "17",
    height: "9",
    rx: "2",
    fill: "currentColor"
  }), /*#__PURE__*/React.createElement("rect", {
    x: "24",
    y: "4",
    width: "1.5",
    height: "5",
    rx: "0.75",
    fill: "currentColor",
    opacity: "0.4"
  }))));
}
function PhoneFrame({
  children,
  dark = false
}) {
  return /*#__PURE__*/React.createElement("div", {
    style: {
      width: 390,
      borderRadius: 54,
      padding: 11,
      background: "#0C0B10",
      boxShadow: "0 40px 90px rgba(40,30,80,.30), 0 8px 24px rgba(40,30,80,.18)"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      position: "relative",
      borderRadius: 44,
      overflow: "hidden",
      background: dark ? "var(--ink-900)" : "var(--bg)",
      height: 800,
      display: "flex",
      flexDirection: "column"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      position: "absolute",
      top: 11,
      left: "50%",
      transform: "translateX(-50%)",
      width: 116,
      height: 33,
      background: "#0C0B10",
      borderRadius: 999,
      zIndex: 50
    }
  }), children));
}
function BottomNav({
  active,
  onChange
}) {
  const items = [{
    key: "home",
    icon: "home",
    label: "Home"
  }, {
    key: "report",
    icon: "pie-chart",
    label: "Report"
  }, {
    key: "coach",
    icon: "sparkles",
    label: "Coach"
  }, {
    key: "settings",
    icon: "settings",
    label: "Settings"
  }];
  return /*#__PURE__*/React.createElement("div", {
    style: {
      position: "relative",
      display: "flex",
      alignItems: "center",
      justifyContent: "space-around",
      background: "var(--surface)",
      borderTop: "1px solid var(--border-hairline)",
      padding: "12px 14px 26px",
      flex: "none"
    }
  }, items.slice(0, 2).map(it => /*#__PURE__*/React.createElement(NavItem, _extends({
    key: it.key
  }, it, {
    active: active === it.key,
    onClick: () => onChange(it.key)
  }))), /*#__PURE__*/React.createElement("div", {
    style: {
      width: 60,
      flex: "none"
    }
  }), items.slice(2).map(it => /*#__PURE__*/React.createElement(NavItem, _extends({
    key: it.key
  }, it, {
    active: active === it.key,
    onClick: () => onChange(it.key)
  }))), /*#__PURE__*/React.createElement("div", {
    style: {
      position: "absolute",
      top: -18,
      left: "50%",
      transform: "translateX(-50%)"
    }
  }, /*#__PURE__*/React.createElement(IconButton, {
    icon: "plus",
    variant: "fab",
    ariaLabel: "Add transaction",
    onClick: () => onChange("add")
  })));
}
function NavItem({
  icon,
  label,
  active,
  onClick
}) {
  return /*#__PURE__*/React.createElement("button", {
    type: "button",
    onClick: onClick,
    style: {
      display: "flex",
      flexDirection: "column",
      alignItems: "center",
      gap: 4,
      background: "none",
      border: "none",
      cursor: "pointer",
      minWidth: 56
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    name: icon,
    size: 22,
    color: active ? "var(--violet-600)" : "var(--gray-400)",
    strokeWidth: active ? 2.4 : 2
  }), /*#__PURE__*/React.createElement("span", {
    style: {
      font: `${active ? 700 : 600} 11px var(--font-sans)`,
      color: active ? "var(--ink-900)" : "var(--gray-400)"
    }
  }, label));
}
Object.assign(window, {
  StatusBar,
  PhoneFrame,
  BottomNav,
  NavItem
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/mobile_app/Chrome.jsx", error: String((e && e.message) || e) }); }

// ui_kits/mobile_app/CoachScreen.jsx
try { (() => {
/* Olmenta mobile — Coach: the conversational AI surface. */
const {
  CoachMessage,
  CoachSuggestion,
  IconButton,
  Icon,
  BudgetBar,
  Button
} = window.OlmentaDesignSystem_4bdf9c;
function CoachHeader({
  onBack
}) {
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      alignItems: "center",
      gap: 12,
      padding: "6px 20px 16px",
      borderBottom: "1px solid var(--border-hairline)"
    }
  }, /*#__PURE__*/React.createElement(IconButton, {
    icon: "arrow-left",
    variant: "ghost",
    size: "sm",
    ariaLabel: "Back",
    onClick: onBack
  }), /*#__PURE__*/React.createElement("span", {
    style: {
      width: 40,
      height: 40,
      borderRadius: 999,
      background: "var(--grad-coach)",
      display: "flex",
      alignItems: "center",
      justifyContent: "center",
      flex: "none"
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    name: "sparkles",
    size: 19,
    color: "var(--mint-400)"
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      font: "700 16px var(--font-sans)",
      letterSpacing: "-0.3px",
      color: "var(--text-strong)"
    }
  }, "Coach"), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      alignItems: "center",
      gap: 5,
      font: "500 12px var(--font-sans)",
      color: "var(--mint-600)"
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      width: 7,
      height: 7,
      borderRadius: 999,
      background: "var(--mint-500)"
    }
  }), " Always here")), /*#__PURE__*/React.createElement(IconButton, {
    icon: "more-horizontal",
    variant: "ghost",
    size: "sm",
    ariaLabel: "More"
  }));
}
function CoachScreen({
  onBack
}) {
  const [draft, setDraft] = React.useState("");
  return /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1,
      display: "flex",
      flexDirection: "column",
      background: "var(--bg)",
      minHeight: 0
    }
  }, /*#__PURE__*/React.createElement(StatusBar, null), /*#__PURE__*/React.createElement(CoachHeader, {
    onBack: onBack
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1,
      overflowY: "auto",
      padding: "18px 18px",
      display: "flex",
      flexDirection: "column",
      gap: 14
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      textAlign: "center",
      font: "500 11.5px var(--font-mono)",
      color: "var(--text-subtle)",
      letterSpacing: "0.3px"
    }
  }, "TODAY \xB7 9:41"), /*#__PURE__*/React.createElement(CoachMessage, {
    role: "coach"
  }, "Morning, Maya \uD83D\uDC4B Your dining spend is up ", /*#__PURE__*/React.createElement("b", null, "18%"), " this month \u2014 mostly caf\xE9s on weekends."), /*#__PURE__*/React.createElement(CoachMessage, {
    role: "coach"
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      marginBottom: 10
    }
  }, "Here's where Food & dining sits against your budget:"), /*#__PURE__*/React.createElement("div", {
    style: {
      background: "var(--bg)",
      borderRadius: "var(--r-md)",
      padding: "12px 12px"
    }
  }, /*#__PURE__*/React.createElement(BudgetBar, {
    icon: "coffee",
    tone: "warning",
    label: "Food & dining",
    spent: "$8,846",
    limit: "$9,000"
  }))), /*#__PURE__*/React.createElement(CoachMessage, {
    role: "user"
  }, "Yikes. Can you cap it?"), /*#__PURE__*/React.createElement(CoachMessage, {
    role: "coach"
  }, "On it. I'll set a ", /*#__PURE__*/React.createElement("b", null, "$300 weekly cap"), " and nudge you at 80%. You're still on track for your Japan goal \uD83C\uDF8C"), /*#__PURE__*/React.createElement("div", {
    style: {
      paddingLeft: 40
    }
  }, /*#__PURE__*/React.createElement(Button, {
    variant: "accent",
    size: "sm",
    iconLeft: "check"
  }, "Set the $300 cap"))), /*#__PURE__*/React.createElement("div", {
    style: {
      flex: "none",
      padding: "12px 16px 14px",
      borderTop: "1px solid var(--border-hairline)",
      background: "var(--surface)"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      marginBottom: 12
    }
  }, /*#__PURE__*/React.createElement(CoachSuggestion, {
    suggestions: [{
      label: "Where can I cut back?",
      icon: "trending-down"
    }, {
      label: "On track for Japan?",
      icon: "plane"
    }],
    onPick: setDraft
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      alignItems: "center",
      gap: 10
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      flex: 1,
      display: "flex",
      alignItems: "center",
      gap: 9,
      background: "var(--surface-sunk)",
      borderRadius: 999,
      padding: "0 16px",
      height: 48
    }
  }, /*#__PURE__*/React.createElement("input", {
    value: draft,
    onChange: e => setDraft(e.target.value),
    placeholder: "Ask the coach anything\u2026",
    style: {
      flex: 1,
      border: "none",
      outline: "none",
      background: "transparent",
      font: "500 15px var(--font-sans)",
      color: "var(--text-strong)",
      minWidth: 0
    }
  })), /*#__PURE__*/React.createElement(IconButton, {
    icon: "send",
    variant: "fab",
    size: "md",
    ariaLabel: "Send"
  }))));
}
Object.assign(window, {
  CoachScreen
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/mobile_app/CoachScreen.jsx", error: String((e && e.message) || e) }); }

// ui_kits/mobile_app/HomeScreen.jsx
try { (() => {
/* Olmenta mobile — Home: gradient balance header + white sheet with money,
   the coach capsule, and the transaction feed. */
const {
  BalanceCard,
  StatCard,
  CoachCapsule,
  TransactionRow,
  Avatar,
  IconButton,
  Icon,
  Badge
} = window.OlmentaDesignSystem_4bdf9c;
function HomeHeader() {
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      alignItems: "center",
      justifyContent: "space-between",
      padding: "6px 22px 0"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      alignItems: "center",
      gap: 11
    }
  }, /*#__PURE__*/React.createElement(Avatar, {
    name: "Maya Ortiz",
    size: 42,
    badge: /*#__PURE__*/React.createElement(Icon, {
      name: "wallet",
      size: 11,
      color: "#fff"
    })
  }), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    style: {
      font: "500 12px var(--font-sans)",
      color: "rgba(255,255,255,.75)"
    }
  }, "Welcome back"), /*#__PURE__*/React.createElement("div", {
    style: {
      font: "700 15px var(--font-sans)",
      color: "#fff",
      letterSpacing: "-0.2px"
    }
  }, "Maya Ortiz"))), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      alignItems: "center",
      gap: 8
    }
  }, /*#__PURE__*/React.createElement("button", {
    type: "button",
    style: {
      display: "flex",
      alignItems: "center",
      gap: 6,
      background: "rgba(255,255,255,.16)",
      border: "none",
      borderRadius: 999,
      padding: "8px 13px",
      color: "#fff",
      font: "600 13px var(--font-sans)",
      cursor: "pointer",
      backdropFilter: "blur(6px)"
    }
  }, "November 2025 ", /*#__PURE__*/React.createElement(Icon, {
    name: "chevron-down",
    size: 15
  })), /*#__PURE__*/React.createElement("button", {
    type: "button",
    style: {
      position: "relative",
      width: 40,
      height: 40,
      borderRadius: 999,
      background: "rgba(255,255,255,.16)",
      border: "none",
      display: "flex",
      alignItems: "center",
      justifyContent: "center",
      color: "#fff",
      cursor: "pointer",
      backdropFilter: "blur(6px)"
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    name: "bell",
    size: 19
  }), /*#__PURE__*/React.createElement("span", {
    style: {
      position: "absolute",
      top: 9,
      right: 10,
      width: 8,
      height: 8,
      borderRadius: 999,
      background: "var(--expense)",
      border: "1.5px solid var(--violet-500)"
    }
  }))));
}
function HomeScreen({
  onOpenCoach
}) {
  return /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1,
      overflowY: "auto",
      overflowX: "hidden",
      background: "var(--bg)"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      background: "var(--grad-violet)",
      padding: "0 0 60px"
    }
  }, /*#__PURE__*/React.createElement(StatusBar, {
    dark: true
  }), /*#__PURE__*/React.createElement(HomeHeader, null), /*#__PURE__*/React.createElement("div", {
    style: {
      textAlign: "center",
      marginTop: 22
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      font: "500 14px var(--font-sans)",
      color: "rgba(255,255,255,.8)"
    }
  }, "Current balance"), /*#__PURE__*/React.createElement("div", {
    style: {
      font: "800 46px var(--font-sans)",
      letterSpacing: "-1.8px",
      color: "#fff",
      marginTop: 6,
      fontVariantNumeric: "tabular-nums"
    }
  }, "$87,457", /*#__PURE__*/React.createElement("span", {
    style: {
      opacity: 0.55
    }
  }, ".85")), /*#__PURE__*/React.createElement("span", {
    style: {
      display: "inline-flex",
      alignItems: "center",
      gap: 5,
      background: "rgba(255,255,255,.18)",
      color: "#fff",
      padding: "7px 14px",
      borderRadius: 999,
      font: "600 13px var(--font-sans)",
      marginTop: 12,
      backdropFilter: "blur(6px)"
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    name: "trending-up",
    size: 15
  }), " $784 than last week"))), /*#__PURE__*/React.createElement("div", {
    style: {
      background: "var(--bg)",
      borderRadius: "30px 30px 0 0",
      marginTop: -34,
      padding: "24px 20px 24px",
      position: "relative"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      alignItems: "center",
      justifyContent: "space-between",
      marginBottom: 14
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      alignItems: "center",
      gap: 6
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      font: "700 19px var(--font-sans)",
      letterSpacing: "-0.4px",
      color: "var(--text-strong)"
    }
  }, "Your money"), /*#__PURE__*/React.createElement(Icon, {
    name: "info",
    size: 15,
    color: "var(--text-subtle)"
  })), /*#__PURE__*/React.createElement("button", {
    type: "button",
    style: {
      display: "flex",
      alignItems: "center",
      gap: 3,
      background: "var(--surface)",
      border: "1px solid var(--border-hairline)",
      borderRadius: 999,
      padding: "7px 13px",
      font: "600 13px var(--font-sans)",
      color: "var(--text-body)",
      cursor: "pointer"
    }
  }, "Details ", /*#__PURE__*/React.createElement(Icon, {
    name: "chevron-right",
    size: 15
  }))), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "grid",
      gridTemplateColumns: "1fr 1fr",
      gap: 12
    }
  }, /*#__PURE__*/React.createElement(StatCard, {
    icon: "trending-up",
    tone: "income",
    label: "Income",
    value: "$4,875.12"
  }), /*#__PURE__*/React.createElement(StatCard, {
    icon: "trending-down",
    tone: "expense",
    label: "Expenses",
    value: "$8,145.78"
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      marginTop: 16
    }
  }, /*#__PURE__*/React.createElement(CoachCapsule, {
    message: "You're spending 18% more on dining",
    cta: "See why",
    onClick: onOpenCoach
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      alignItems: "center",
      justifyContent: "space-between",
      margin: "24px 0 14px"
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      font: "700 19px var(--font-sans)",
      letterSpacing: "-0.4px",
      color: "var(--text-strong)"
    }
  }, "Transactions"), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      alignItems: "center",
      gap: 8
    }
  }, /*#__PURE__*/React.createElement(IconButton, {
    icon: "pin",
    variant: "ghost",
    size: "sm",
    ariaLabel: "Pinned"
  }), /*#__PURE__*/React.createElement(IconButton, {
    icon: "clock",
    variant: "ghost",
    size: "sm",
    ariaLabel: "Recent"
  }), /*#__PURE__*/React.createElement(Badge, {
    tone: "brand",
    dot: true
  }, "For the period"))), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      alignItems: "center",
      justifyContent: "space-between",
      margin: "0 2px 12px"
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      font: "500 13px var(--font-sans)",
      color: "var(--text-muted)"
    }
  }, "Monday, 12 January 2026"), /*#__PURE__*/React.createElement("span", {
    style: {
      font: "500 12.5px var(--font-mono)",
      color: "var(--text-subtle)"
    }
  }, "Total $2,95,776")), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      flexDirection: "column",
      gap: 10
    }
  }, /*#__PURE__*/React.createElement(TransactionRow, {
    icon: "wallet",
    tone: "violet",
    title: "Cash, EUR",
    subtitle: "\u21B3 Red Card",
    amount: "354.25",
    direction: "out",
    balance: "$4,245.21"
  }), /*#__PURE__*/React.createElement(TransactionRow, {
    icon: "coffee",
    tone: "info",
    title: "Caf\xE9s",
    subtitle: /*#__PURE__*/React.createElement(Badge, {
      tone: "neutral",
      dot: true
    }, "Vacation"),
    amount: "12.49",
    direction: "out"
  }), /*#__PURE__*/React.createElement(TransactionRow, {
    icon: "dollar-sign",
    tone: "income",
    title: "Salary",
    subtitle: "\u21B3 Main account",
    amount: "4,875.12",
    direction: "in"
  }), /*#__PURE__*/React.createElement(TransactionRow, {
    icon: "shopping-bag",
    tone: "violet",
    title: "Shopping",
    subtitle: "\u21B3 Apple Card",
    amount: "129.00",
    direction: "out"
  }))));
}
Object.assign(window, {
  HomeScreen
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/mobile_app/HomeScreen.jsx", error: String((e && e.message) || e) }); }

// ui_kits/mobile_app/ReportScreen.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/* Olmenta mobile — Report: expenses/income lens, donut breakdown, categories. */
const {
  SegmentedControl,
  IconButton,
  Icon,
  IconChip,
  BudgetBar,
  Badge
} = window.OlmentaDesignSystem_4bdf9c;
function Donut() {
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      flexDirection: "column",
      alignItems: "center",
      padding: "8px 0 4px"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      position: "relative",
      width: 210,
      height: 210,
      borderRadius: "50%",
      background: "conic-gradient(var(--chart-1) 0 31%, var(--chart-3) 31% 55%, var(--chart-2) 55% 76%, var(--chart-4) 76% 90%, var(--chart-empty) 90% 100%)",
      display: "flex",
      alignItems: "center",
      justifyContent: "center"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      width: 132,
      height: 132,
      background: "var(--surface)",
      borderRadius: "50%",
      display: "flex",
      flexDirection: "column",
      alignItems: "center",
      justifyContent: "center"
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      font: "500 12px var(--font-sans)",
      color: "var(--text-muted)"
    }
  }, "Total expenses"), /*#__PURE__*/React.createElement("span", {
    style: {
      font: "800 24px var(--font-sans)",
      letterSpacing: "-0.8px",
      color: "var(--text-strong)",
      fontVariantNumeric: "tabular-nums"
    }
  }, "$42,124")), /*#__PURE__*/React.createElement("span", {
    style: {
      position: "absolute",
      top: 18,
      right: 4,
      background: "var(--ink-900)",
      color: "#fff",
      font: "700 12px var(--font-mono)",
      padding: "5px 10px",
      borderRadius: 999
    }
  }, "31%")));
}
function ReportScreen() {
  const cats = [{
    icon: "shopping-bag",
    tone: "violet",
    label: "Shopping",
    spent: "$13,058",
    limit: "$15,000"
  }, {
    icon: "receipt",
    tone: "info",
    label: "Bills & utilities",
    spent: "$10,109",
    limit: "$10,000"
  }, {
    icon: "coffee",
    tone: "mint",
    label: "Food & dining",
    spent: "$8,846",
    limit: "$12,000"
  }, {
    icon: "plane",
    tone: "warning",
    label: "Travel",
    spent: "$5,897",
    limit: "$8,000"
  }];
  return /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1,
      overflowY: "auto",
      overflowX: "hidden",
      background: "var(--bg)"
    }
  }, /*#__PURE__*/React.createElement(StatusBar, null), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      alignItems: "center",
      justifyContent: "space-between",
      padding: "6px 20px 0"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      alignItems: "center",
      gap: 12
    }
  }, /*#__PURE__*/React.createElement(IconButton, {
    icon: "arrow-left",
    variant: "ghost",
    size: "sm",
    ariaLabel: "Back"
  }), /*#__PURE__*/React.createElement("span", {
    style: {
      font: "700 22px var(--font-sans)",
      letterSpacing: "-0.5px",
      color: "var(--text-strong)"
    }
  }, "Report")), /*#__PURE__*/React.createElement("button", {
    type: "button",
    style: {
      display: "flex",
      alignItems: "center",
      gap: 6,
      background: "var(--surface)",
      border: "1px solid var(--border-hairline)",
      borderRadius: 999,
      padding: "8px 13px",
      color: "var(--text-body)",
      font: "600 13px var(--font-sans)",
      cursor: "pointer"
    }
  }, "November 2025 ", /*#__PURE__*/React.createElement(Icon, {
    name: "chevron-down",
    size: 15
  }))), /*#__PURE__*/React.createElement("div", {
    style: {
      padding: "18px 20px 24px"
    }
  }, /*#__PURE__*/React.createElement(SegmentedControl, {
    options: ["Expenses", "Income"],
    defaultValue: "Expenses"
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      alignItems: "center",
      justifyContent: "space-between",
      margin: "22px 0 4px"
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      font: "700 18px var(--font-sans)",
      letterSpacing: "-0.3px",
      color: "var(--text-strong)"
    }
  }, "Expenses report"), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      background: "var(--surface-sunk)",
      borderRadius: 999,
      padding: 4,
      gap: 2
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      width: 34,
      height: 34,
      borderRadius: 999,
      display: "flex",
      alignItems: "center",
      justifyContent: "center",
      color: "var(--text-muted)"
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    name: "bar-chart",
    size: 17
  })), /*#__PURE__*/React.createElement("span", {
    style: {
      width: 34,
      height: 34,
      borderRadius: 999,
      background: "var(--surface)",
      boxShadow: "var(--shadow-sm)",
      display: "flex",
      alignItems: "center",
      justifyContent: "center",
      color: "var(--violet-600)"
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    name: "pie-chart",
    size: 17
  })))), /*#__PURE__*/React.createElement(Donut, null), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      flexWrap: "wrap",
      gap: 10,
      justifyContent: "center",
      margin: "18px 0 4px"
    }
  }, [["var(--chart-1)", "Shopping 31%"], ["var(--chart-3)", "Bills 24%"], ["var(--chart-2)", "Food 21%"], ["var(--chart-4)", "Travel 14%"], ["var(--chart-empty)", "Other 10%"]].map(([c, l]) => /*#__PURE__*/React.createElement("span", {
    key: l,
    style: {
      display: "flex",
      alignItems: "center",
      gap: 6,
      font: "500 12px var(--font-sans)",
      color: "var(--text-muted)"
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      width: 10,
      height: 10,
      borderRadius: 3,
      background: c
    }
  }), " ", l))), /*#__PURE__*/React.createElement("div", {
    style: {
      background: "var(--surface)",
      border: "1px solid var(--border-hairline)",
      borderRadius: "var(--r-xl)",
      padding: "18px 18px",
      boxShadow: "var(--shadow-sm)",
      marginTop: 18
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      alignItems: "center",
      justifyContent: "space-between",
      marginBottom: 16
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      font: "700 16px var(--font-sans)",
      letterSpacing: "-0.3px",
      color: "var(--text-strong)"
    }
  }, "By category"), /*#__PURE__*/React.createElement(Badge, {
    tone: "brand"
  }, "5 categories")), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      flexDirection: "column",
      gap: 17
    }
  }, cats.map(c => /*#__PURE__*/React.createElement(BudgetBar, _extends({
    key: c.label
  }, c)))))));
}
Object.assign(window, {
  ReportScreen
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/mobile_app/ReportScreen.jsx", error: String((e && e.message) || e) }); }

// ui_kits/mobile_app/SettingsScreen.jsx
try { (() => {
/* Olmenta mobile — Settings: profile, preferences, coach controls. */
const {
  Avatar,
  Switch,
  Icon,
  Badge,
  IconChip
} = window.OlmentaDesignSystem_4bdf9c;
function Row({
  icon,
  tone,
  label,
  sub,
  right,
  last
}) {
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      alignItems: "center",
      gap: 13,
      padding: "13px 0",
      borderBottom: last ? "none" : "1px solid var(--border-hairline)"
    }
  }, /*#__PURE__*/React.createElement(IconChip, {
    icon: icon,
    tone: tone,
    size: 38
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1,
      minWidth: 0
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      font: "600 15px var(--font-sans)",
      color: "var(--text-strong)",
      letterSpacing: "-0.1px"
    }
  }, label), sub && /*#__PURE__*/React.createElement("div", {
    style: {
      font: "500 12.5px var(--font-sans)",
      color: "var(--text-muted)",
      marginTop: 1
    }
  }, sub)), right);
}
function SettingsScreen() {
  return /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1,
      overflowY: "auto",
      overflowX: "hidden",
      background: "var(--bg)"
    }
  }, /*#__PURE__*/React.createElement(StatusBar, null), /*#__PURE__*/React.createElement("div", {
    style: {
      padding: "6px 20px 24px"
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      font: "700 22px var(--font-sans)",
      letterSpacing: "-0.5px",
      color: "var(--text-strong)"
    }
  }, "Settings"), /*#__PURE__*/React.createElement("div", {
    style: {
      background: "var(--surface)",
      border: "1px solid var(--border-hairline)",
      borderRadius: "var(--r-xl)",
      padding: 18,
      boxShadow: "var(--shadow-sm)",
      marginTop: 16,
      display: "flex",
      alignItems: "center",
      gap: 14
    }
  }, /*#__PURE__*/React.createElement(Avatar, {
    name: "Maya Ortiz",
    ring: "brand",
    size: 56
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      font: "700 17px var(--font-sans)",
      letterSpacing: "-0.3px",
      color: "var(--text-strong)"
    }
  }, "Maya Ortiz"), /*#__PURE__*/React.createElement("div", {
    style: {
      font: "500 13px var(--font-sans)",
      color: "var(--text-muted)",
      marginTop: 1
    }
  }, "maya@olmenta.app")), /*#__PURE__*/React.createElement(Badge, {
    tone: "mint",
    icon: "sparkles"
  }, "Pro")), /*#__PURE__*/React.createElement("div", {
    style: {
      font: "var(--t-eyebrow-fw) var(--t-eyebrow-size)/1 var(--font-sans)",
      letterSpacing: "var(--t-eyebrow-ls)",
      textTransform: "uppercase",
      color: "var(--text-subtle)",
      margin: "24px 2px 6px"
    }
  }, "Coach"), /*#__PURE__*/React.createElement("div", {
    style: {
      background: "var(--surface)",
      border: "1px solid var(--border-hairline)",
      borderRadius: "var(--r-xl)",
      padding: "4px 16px",
      boxShadow: "var(--shadow-sm)"
    }
  }, /*#__PURE__*/React.createElement(Row, {
    icon: "sparkles",
    tone: "violet",
    label: "Proactive insights",
    sub: "Let the coach reach out",
    right: /*#__PURE__*/React.createElement(Switch, {
      defaultChecked: true
    })
  }), /*#__PURE__*/React.createElement(Row, {
    icon: "bell",
    tone: "info",
    label: "Spending nudges",
    sub: "When you near a cap",
    right: /*#__PURE__*/React.createElement(Switch, {
      defaultChecked: true
    }),
    last: true
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      font: "var(--t-eyebrow-fw) var(--t-eyebrow-size)/1 var(--font-sans)",
      letterSpacing: "var(--t-eyebrow-ls)",
      textTransform: "uppercase",
      color: "var(--text-subtle)",
      margin: "24px 2px 6px"
    }
  }, "Account"), /*#__PURE__*/React.createElement("div", {
    style: {
      background: "var(--surface)",
      border: "1px solid var(--border-hairline)",
      borderRadius: "var(--r-xl)",
      padding: "4px 16px",
      boxShadow: "var(--shadow-sm)"
    }
  }, /*#__PURE__*/React.createElement(Row, {
    icon: "wallet",
    tone: "violet",
    label: "Accounts & cards",
    sub: "3 linked",
    right: /*#__PURE__*/React.createElement(Icon, {
      name: "chevron-right",
      size: 18,
      color: "var(--text-subtle)"
    })
  }), /*#__PURE__*/React.createElement(Row, {
    icon: "target",
    tone: "mint",
    label: "Goals",
    sub: "Japan trip \xB7 68%",
    right: /*#__PURE__*/React.createElement(Icon, {
      name: "chevron-right",
      size: 18,
      color: "var(--text-subtle)"
    })
  }), /*#__PURE__*/React.createElement(Row, {
    icon: "lock",
    tone: "neutral",
    label: "Privacy & security",
    right: /*#__PURE__*/React.createElement(Icon, {
      name: "chevron-right",
      size: 18,
      color: "var(--text-subtle)"
    }),
    last: true
  }))));
}
Object.assign(window, {
  SettingsScreen
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/mobile_app/SettingsScreen.jsx", error: String((e && e.message) || e) }); }

// ui_kits/web_app/CoachPanel.jsx
try { (() => {
/* Olmenta web — persistent Coach rail on the right of the dashboard. */
const {
  CoachMessage,
  CoachSuggestion,
  IconButton,
  Icon,
  BudgetBar,
  Button,
  Badge
} = window.OlmentaDesignSystem_4bdf9c;
function CoachPanel() {
  const [draft, setDraft] = React.useState("");
  return /*#__PURE__*/React.createElement("aside", {
    style: {
      width: 360,
      flex: "none",
      background: "var(--surface)",
      borderLeft: "1px solid var(--border-hairline)",
      display: "flex",
      flexDirection: "column",
      height: "100%"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      alignItems: "center",
      gap: 12,
      padding: "20px 20px",
      borderBottom: "1px solid var(--border-hairline)"
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      width: 40,
      height: 40,
      borderRadius: 999,
      background: "var(--grad-coach)",
      display: "flex",
      alignItems: "center",
      justifyContent: "center",
      flex: "none"
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    name: "sparkles",
    size: 19,
    color: "var(--mint-400)"
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      font: "700 16px var(--font-sans)",
      letterSpacing: "-0.3px",
      color: "var(--text-strong)"
    }
  }, "Coach"), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      alignItems: "center",
      gap: 5,
      font: "500 12px var(--font-sans)",
      color: "var(--mint-600)"
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      width: 7,
      height: 7,
      borderRadius: 999,
      background: "var(--mint-500)"
    }
  }), " Watching your money")), /*#__PURE__*/React.createElement(IconButton, {
    icon: "more-horizontal",
    variant: "ghost",
    size: "sm",
    ariaLabel: "More"
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1,
      overflowY: "auto",
      padding: "20px 18px",
      display: "flex",
      flexDirection: "column",
      gap: 14
    }
  }, /*#__PURE__*/React.createElement(CoachMessage, {
    role: "coach"
  }, "Your dining spend is up ", /*#__PURE__*/React.createElement("b", null, "18%"), " this month \u2014 mostly weekend caf\xE9s."), /*#__PURE__*/React.createElement(CoachMessage, {
    role: "coach"
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      marginBottom: 10
    }
  }, "Food & dining vs budget:"), /*#__PURE__*/React.createElement("div", {
    style: {
      background: "var(--bg)",
      borderRadius: "var(--r-md)",
      padding: 12
    }
  }, /*#__PURE__*/React.createElement(BudgetBar, {
    icon: "coffee",
    tone: "warning",
    label: "Food & dining",
    spent: "$8,846",
    limit: "$9,000"
  }))), /*#__PURE__*/React.createElement(CoachMessage, {
    role: "user"
  }, "Can you cap it?"), /*#__PURE__*/React.createElement(CoachMessage, {
    role: "coach"
  }, "Setting a ", /*#__PURE__*/React.createElement("b", null, "$300 weekly cap"), ". You're still on track for Japan \uD83C\uDF8C"), /*#__PURE__*/React.createElement("div", {
    style: {
      paddingLeft: 40
    }
  }, /*#__PURE__*/React.createElement(Button, {
    variant: "accent",
    size: "sm",
    iconLeft: "check"
  }, "Set the $300 cap"))), /*#__PURE__*/React.createElement("div", {
    style: {
      flex: "none",
      padding: "12px 16px 16px",
      borderTop: "1px solid var(--border-hairline)"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      marginBottom: 12
    }
  }, /*#__PURE__*/React.createElement(CoachSuggestion, {
    suggestions: [{
      label: "Where can I cut back?",
      icon: "trending-down"
    }, {
      label: "On track for Japan?",
      icon: "plane"
    }],
    onPick: setDraft
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      alignItems: "center",
      gap: 10
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      flex: 1,
      display: "flex",
      alignItems: "center",
      gap: 9,
      background: "var(--surface-sunk)",
      borderRadius: 999,
      padding: "0 16px",
      height: 46
    }
  }, /*#__PURE__*/React.createElement("input", {
    value: draft,
    onChange: e => setDraft(e.target.value),
    placeholder: "Ask the coach\u2026",
    style: {
      flex: 1,
      border: "none",
      outline: "none",
      background: "transparent",
      font: "500 14.5px var(--font-sans)",
      color: "var(--text-strong)",
      minWidth: 0
    }
  })), /*#__PURE__*/React.createElement(IconButton, {
    icon: "send",
    variant: "fab",
    size: "md",
    ariaLabel: "Send"
  }))));
}
Object.assign(window, {
  CoachPanel
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/web_app/CoachPanel.jsx", error: String((e && e.message) || e) }); }

// ui_kits/web_app/Dashboard.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/* Olmenta web — Overview dashboard content. */
const {
  BalanceCard,
  StatCard,
  TransactionRow,
  BudgetBar,
  Badge,
  Icon,
  IconChip,
  Button
} = window.OlmentaDesignSystem_4bdf9c;
function Panel({
  title,
  action,
  children,
  style
}) {
  return /*#__PURE__*/React.createElement("section", {
    style: {
      background: "var(--surface)",
      border: "1px solid var(--border-hairline)",
      borderRadius: "var(--r-xl)",
      padding: 22,
      boxShadow: "var(--shadow-sm)",
      ...style
    }
  }, title && /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      alignItems: "center",
      justifyContent: "space-between",
      marginBottom: 18
    }
  }, /*#__PURE__*/React.createElement("h2", {
    style: {
      font: "700 17px var(--font-sans)",
      letterSpacing: "-0.3px",
      color: "var(--text-strong)"
    }
  }, title), action), children);
}
function SpendChart() {
  const weeks = [{
    l: "W1",
    a: 62,
    b: 38
  }, {
    l: "W2",
    a: 80,
    b: 52
  }, {
    l: "W3",
    a: 48,
    b: 30
  }, {
    l: "W4",
    a: 92,
    b: 60
  }, {
    l: "W5",
    a: 70,
    b: 44
  }];
  return /*#__PURE__*/React.createElement(Panel, {
    title: "Spending this month",
    action: /*#__PURE__*/React.createElement("div", {
      style: {
        display: "flex",
        gap: 14
      }
    }, /*#__PURE__*/React.createElement("span", {
      style: {
        display: "flex",
        alignItems: "center",
        gap: 6,
        font: "500 12px var(--font-sans)",
        color: "var(--text-muted)"
      }
    }, /*#__PURE__*/React.createElement("span", {
      style: {
        width: 10,
        height: 10,
        borderRadius: 3,
        background: "var(--violet-500)"
      }
    }), " Spent"), /*#__PURE__*/React.createElement("span", {
      style: {
        display: "flex",
        alignItems: "center",
        gap: 6,
        font: "500 12px var(--font-sans)",
        color: "var(--text-muted)"
      }
    }, /*#__PURE__*/React.createElement("span", {
      style: {
        width: 10,
        height: 10,
        borderRadius: 3,
        background: "var(--mint-400)"
      }
    }), " Saved"))
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      alignItems: "flex-end",
      justifyContent: "space-between",
      gap: 18,
      height: 180,
      padding: "0 4px"
    }
  }, weeks.map(w => /*#__PURE__*/React.createElement("div", {
    key: w.l,
    style: {
      flex: 1,
      display: "flex",
      flexDirection: "column",
      alignItems: "center",
      gap: 10
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      alignItems: "flex-end",
      gap: 6,
      height: 150,
      width: "100%",
      justifyContent: "center"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      width: 14,
      height: `${w.a}%`,
      background: "var(--grad-balance)",
      borderRadius: "6px 6px 3px 3px"
    }
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      width: 14,
      height: `${w.b}%`,
      background: "var(--mint-300)",
      borderRadius: "6px 6px 3px 3px"
    }
  })), /*#__PURE__*/React.createElement("span", {
    style: {
      font: "600 12px var(--font-sans)",
      color: "var(--text-subtle)"
    }
  }, w.l)))));
}
function Dashboard() {
  return /*#__PURE__*/React.createElement("div", {
    style: {
      padding: 28,
      display: "flex",
      flexDirection: "column",
      gap: 20
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: "grid",
      gridTemplateColumns: "1.5fr 1fr 1fr",
      gap: 20
    }
  }, /*#__PURE__*/React.createElement(BalanceCard, {
    label: "Current balance",
    amount: "$87,457",
    cents: ".85",
    delta: "\u2191 $784 than last week",
    align: "left",
    style: {
      borderRadius: "var(--r-xl)"
    }
  }), /*#__PURE__*/React.createElement(StatCard, {
    icon: "trending-up",
    tone: "income",
    label: "Income",
    value: "$4,875.12"
  }), /*#__PURE__*/React.createElement(StatCard, {
    icon: "trending-down",
    tone: "expense",
    label: "Expenses",
    value: "$8,145.78"
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "grid",
      gridTemplateColumns: "1.5fr 1fr",
      gap: 20
    }
  }, /*#__PURE__*/React.createElement(SpendChart, null), /*#__PURE__*/React.createElement(Panel, {
    title: "Budgets",
    action: /*#__PURE__*/React.createElement(Badge, {
      tone: "brand"
    }, "4 active")
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      flexDirection: "column",
      gap: 17
    }
  }, /*#__PURE__*/React.createElement(BudgetBar, {
    icon: "shopping-bag",
    tone: "violet",
    label: "Shopping",
    spent: "$13,058",
    limit: "$15,000"
  }), /*#__PURE__*/React.createElement(BudgetBar, {
    icon: "receipt",
    tone: "info",
    label: "Bills",
    spent: "$10,109",
    limit: "$10,000"
  }), /*#__PURE__*/React.createElement(BudgetBar, {
    icon: "coffee",
    tone: "mint",
    label: "Food & dining",
    spent: "$8,846",
    limit: "$12,000"
  }), /*#__PURE__*/React.createElement(BudgetBar, {
    icon: "plane",
    tone: "warning",
    label: "Travel",
    spent: "$5,897",
    limit: "$8,000"
  })))), /*#__PURE__*/React.createElement(Panel, {
    title: "Recent transactions",
    action: /*#__PURE__*/React.createElement(Button, {
      variant: "ghost",
      size: "sm",
      iconRight: "chevron-right"
    }, "View all")
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      flexDirection: "column"
    }
  }, [{
    icon: "wallet",
    tone: "violet",
    title: "Cash withdrawal",
    subtitle: "Red Card · 12 Jan",
    amount: "354.25",
    direction: "out"
  }, {
    icon: "dollar-sign",
    tone: "income",
    title: "Salary",
    subtitle: "Main account · 10 Jan",
    amount: "4,875.12",
    direction: "in"
  }, {
    icon: "coffee",
    tone: "info",
    title: "Blue Bottle Coffee",
    subtitle: "Food & dining · 9 Jan",
    amount: "12.49",
    direction: "out"
  }, {
    icon: "shopping-bag",
    tone: "violet",
    title: "Apple Store",
    subtitle: "Shopping · 8 Jan",
    amount: "129.00",
    direction: "out"
  }].map((t, i) => /*#__PURE__*/React.createElement("div", {
    key: i,
    style: {
      borderBottom: i < 3 ? "1px solid var(--border-hairline)" : "none"
    }
  }, /*#__PURE__*/React.createElement(TransactionRow, _extends({}, t, {
    card: false
  })))))));
}
Object.assign(window, {
  Dashboard,
  Panel
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/web_app/Dashboard.jsx", error: String((e && e.message) || e) }); }

// ui_kits/web_app/Shell.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/* Olmenta web — shell chrome: left sidebar + top bar. */
const {
  Icon,
  Avatar,
  SearchInput,
  Badge,
  IconButton
} = window.OlmentaDesignSystem_4bdf9c;
function Logo() {
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      alignItems: "center",
      gap: 11,
      padding: "4px 8px 0"
    }
  }, /*#__PURE__*/React.createElement("img", {
    src: window.__resources && window.__resources.logoMark || "../../assets/olmenta-mark.svg",
    width: "34",
    height: "34",
    alt: "Olmenta"
  }), /*#__PURE__*/React.createElement("span", {
    style: {
      font: "800 21px var(--font-sans)",
      letterSpacing: "-1px",
      color: "var(--ink-900)"
    }
  }, "Olmenta"));
}
function SideItem({
  icon,
  label,
  active,
  onClick
}) {
  return /*#__PURE__*/React.createElement("button", {
    type: "button",
    onClick: onClick,
    style: {
      display: "flex",
      alignItems: "center",
      gap: 12,
      width: "100%",
      textAlign: "left",
      padding: "11px 13px",
      borderRadius: "var(--r-md)",
      border: "none",
      cursor: "pointer",
      background: active ? "var(--violet-100)" : "transparent",
      color: active ? "var(--violet-700)" : "var(--text-muted)",
      font: `${active ? 700 : 600} 14.5px var(--font-sans)`,
      letterSpacing: "-0.1px",
      transition: "background var(--dur-base) var(--ease-out), color var(--dur-base) var(--ease-out)"
    },
    onMouseEnter: e => {
      if (!active) {
        e.currentTarget.style.background = "var(--violet-50)";
        e.currentTarget.style.color = "var(--text-body)";
      }
    },
    onMouseLeave: e => {
      if (!active) {
        e.currentTarget.style.background = "transparent";
        e.currentTarget.style.color = "var(--text-muted)";
      }
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    name: icon,
    size: 20,
    strokeWidth: active ? 2.4 : 2
  }), label);
}
function Sidebar({
  active,
  onChange
}) {
  const items = [{
    key: "overview",
    icon: "dashboard",
    label: "Overview"
  }, {
    key: "transactions",
    icon: "receipt",
    label: "Transactions"
  }, {
    key: "budgets",
    icon: "pie-chart",
    label: "Budgets"
  }, {
    key: "goals",
    icon: "target",
    label: "Goals"
  }];
  return /*#__PURE__*/React.createElement("aside", {
    style: {
      width: 264,
      flex: "none",
      background: "var(--surface)",
      borderRight: "1px solid var(--border-hairline)",
      padding: "22px 16px",
      display: "flex",
      flexDirection: "column",
      height: "100%"
    }
  }, /*#__PURE__*/React.createElement(Logo, null), /*#__PURE__*/React.createElement("nav", {
    style: {
      display: "flex",
      flexDirection: "column",
      gap: 3,
      marginTop: 26
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      font: "var(--t-eyebrow-fw) var(--t-eyebrow-size)/1 var(--font-sans)",
      letterSpacing: "var(--t-eyebrow-ls)",
      textTransform: "uppercase",
      color: "var(--text-subtle)",
      padding: "0 13px 8px"
    }
  }, "Menu"), items.map(it => /*#__PURE__*/React.createElement(SideItem, _extends({
    key: it.key
  }, it, {
    active: active === it.key,
    onClick: () => onChange(it.key)
  })))), /*#__PURE__*/React.createElement("div", {
    style: {
      marginTop: "auto",
      display: "flex",
      flexDirection: "column",
      gap: 14
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      background: "var(--grad-coach)",
      borderRadius: "var(--r-xl)",
      padding: 16,
      color: "#fff"
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      display: "inline-flex",
      width: 30,
      height: 30,
      borderRadius: "var(--r-sm)",
      background: "rgba(255,255,255,.1)",
      alignItems: "center",
      justifyContent: "center",
      marginBottom: 10
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    name: "sparkles",
    size: 16,
    color: "var(--mint-400)"
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      font: "700 14.5px var(--font-sans)",
      letterSpacing: "-0.2px"
    }
  }, "Olmenta Pro"), /*#__PURE__*/React.createElement("div", {
    style: {
      font: "500 12.5px/1.45 var(--font-sans)",
      color: "rgba(255,255,255,.7)",
      margin: "4px 0 12px"
    }
  }, "Deeper coaching, unlimited goals."), /*#__PURE__*/React.createElement("button", {
    type: "button",
    style: {
      width: "100%",
      background: "#fff",
      color: "var(--ink-900)",
      border: "none",
      borderRadius: 999,
      padding: "9px",
      font: "600 13.5px var(--font-sans)",
      cursor: "pointer"
    }
  }, "Upgrade")), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      alignItems: "center",
      gap: 11,
      padding: "8px 6px"
    }
  }, /*#__PURE__*/React.createElement(Avatar, {
    name: "Maya Ortiz",
    size: 38
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1,
      minWidth: 0
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      font: "700 13.5px var(--font-sans)",
      color: "var(--text-strong)"
    }
  }, "Maya Ortiz"), /*#__PURE__*/React.createElement("div", {
    style: {
      font: "500 12px var(--font-sans)",
      color: "var(--text-muted)",
      overflow: "hidden",
      textOverflow: "ellipsis",
      whiteSpace: "nowrap"
    }
  }, "maya@olmenta.app")), /*#__PURE__*/React.createElement(Icon, {
    name: "settings",
    size: 18,
    color: "var(--text-subtle)"
  }))));
}
function TopBar({
  title,
  sub
}) {
  return /*#__PURE__*/React.createElement("header", {
    style: {
      display: "flex",
      alignItems: "center",
      justifyContent: "space-between",
      padding: "22px 28px",
      borderBottom: "1px solid var(--border-hairline)",
      background: "var(--surface)"
    }
  }, /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("h1", {
    style: {
      font: "700 24px var(--font-sans)",
      letterSpacing: "-0.6px",
      color: "var(--text-strong)"
    }
  }, title), sub && /*#__PURE__*/React.createElement("div", {
    style: {
      font: "500 13.5px var(--font-sans)",
      color: "var(--text-muted)",
      marginTop: 2
    }
  }, sub)), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      alignItems: "center",
      gap: 12
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      width: 240
    }
  }, /*#__PURE__*/React.createElement(SearchInput, {
    placeholder: "Search transactions"
  })), /*#__PURE__*/React.createElement("button", {
    type: "button",
    style: {
      display: "flex",
      alignItems: "center",
      gap: 7,
      background: "var(--surface)",
      border: "1px solid var(--border-hairline)",
      borderRadius: 999,
      padding: "9px 14px",
      color: "var(--text-body)",
      font: "600 13.5px var(--font-sans)",
      cursor: "pointer"
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    name: "calendar",
    size: 16,
    color: "var(--text-muted)"
  }), " November 2025 ", /*#__PURE__*/React.createElement(Icon, {
    name: "chevron-down",
    size: 15,
    color: "var(--text-subtle)"
  })), /*#__PURE__*/React.createElement(IconButton, {
    icon: "bell",
    variant: "ghost"
  })));
}
Object.assign(window, {
  Logo,
  Sidebar,
  TopBar
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/web_app/Shell.jsx", error: String((e && e.message) || e) }); }

// ui_kits/web_app/Transactions.jsx
try { (() => {
/* Olmenta web — Transactions table view. */
const {
  TransactionRow,
  Badge,
  Button,
  Icon,
  SegmentedControl,
  IconChip
} = window.OlmentaDesignSystem_4bdf9c;
function TxTable({
  rows
}) {
  return /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    style: {
      display: "grid",
      gridTemplateColumns: "2fr 1.2fr 1fr 0.9fr",
      gap: 16,
      padding: "0 6px 12px",
      borderBottom: "1px solid var(--border-hairline)"
    }
  }, ["Transaction", "Category", "Date", "Amount"].map((h, i) => /*#__PURE__*/React.createElement("span", {
    key: h,
    style: {
      font: "var(--t-eyebrow-fw) var(--t-eyebrow-size)/1 var(--font-sans)",
      letterSpacing: "var(--t-eyebrow-ls)",
      textTransform: "uppercase",
      color: "var(--text-subtle)",
      textAlign: i === 3 ? "right" : "left"
    }
  }, h))), rows.map((r, i) => /*#__PURE__*/React.createElement("div", {
    key: i,
    style: {
      display: "grid",
      gridTemplateColumns: "2fr 1.2fr 1fr 0.9fr",
      gap: 16,
      alignItems: "center",
      padding: "13px 6px",
      borderBottom: i < rows.length - 1 ? "1px solid var(--border-hairline)" : "none"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      alignItems: "center",
      gap: 12
    }
  }, /*#__PURE__*/React.createElement(IconChip, {
    icon: r.icon,
    tone: r.tone,
    size: 40
  }), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    style: {
      font: "600 14.5px var(--font-sans)",
      color: "var(--text-strong)",
      letterSpacing: "-0.1px"
    }
  }, r.title), /*#__PURE__*/React.createElement("div", {
    style: {
      font: "500 12px var(--font-mono)",
      color: "var(--text-subtle)"
    }
  }, r.acct))), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement(Badge, {
    tone: r.badgeTone || "neutral",
    dot: true
  }, r.cat)), /*#__PURE__*/React.createElement("div", {
    style: {
      font: "500 13.5px var(--font-sans)",
      color: "var(--text-muted)"
    }
  }, r.date), /*#__PURE__*/React.createElement("div", {
    style: {
      textAlign: "right",
      font: "700 14.5px var(--font-sans)",
      fontVariantNumeric: "tabular-nums",
      color: r.direction === "in" ? "var(--income)" : "var(--text-strong)"
    }
  }, r.direction === "in" ? "+" : "−", r.amount))));
}
function Transactions() {
  const rows = [{
    icon: "dollar-sign",
    tone: "income",
    title: "Salary",
    acct: "•••• 4821",
    cat: "Income",
    badgeTone: "income",
    date: "10 Jan 2026",
    amount: "$4,875.12",
    direction: "in"
  }, {
    icon: "wallet",
    tone: "violet",
    title: "Cash withdrawal",
    acct: "Red Card",
    cat: "Transfer",
    badgeTone: "brand",
    date: "12 Jan 2026",
    amount: "$354.25",
    direction: "out"
  }, {
    icon: "shopping-bag",
    tone: "violet",
    title: "Apple Store",
    acct: "•••• 0934",
    cat: "Shopping",
    badgeTone: "brand",
    date: "8 Jan 2026",
    amount: "$129.00",
    direction: "out"
  }, {
    icon: "coffee",
    tone: "info",
    title: "Blue Bottle Coffee",
    acct: "•••• 0934",
    cat: "Food",
    badgeTone: "info",
    date: "9 Jan 2026",
    amount: "$12.49",
    direction: "out"
  }, {
    icon: "plane",
    tone: "warning",
    title: "United Airlines",
    acct: "•••• 0934",
    cat: "Travel",
    badgeTone: "warning",
    date: "5 Jan 2026",
    amount: "$642.00",
    direction: "out"
  }, {
    icon: "receipt",
    tone: "mint",
    title: "Con Edison",
    acct: "Auto-pay",
    cat: "Bills",
    badgeTone: "mint",
    date: "3 Jan 2026",
    amount: "$214.30",
    direction: "out"
  }];
  return /*#__PURE__*/React.createElement("div", {
    style: {
      padding: 28,
      display: "flex",
      flexDirection: "column",
      gap: 20
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      alignItems: "center",
      justifyContent: "space-between"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      width: 320
    }
  }, /*#__PURE__*/React.createElement(SegmentedControl, {
    options: ["All", "Expenses", "Income"],
    defaultValue: "All"
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      gap: 10
    }
  }, /*#__PURE__*/React.createElement(Button, {
    variant: "ghost",
    size: "sm",
    iconLeft: "filter"
  }, "Filter"), /*#__PURE__*/React.createElement(Button, {
    variant: "primary",
    size: "sm",
    iconLeft: "plus"
  }, "Add transaction"))), /*#__PURE__*/React.createElement("section", {
    style: {
      background: "var(--surface)",
      border: "1px solid var(--border-hairline)",
      borderRadius: "var(--r-xl)",
      padding: 22,
      boxShadow: "var(--shadow-sm)"
    }
  }, /*#__PURE__*/React.createElement(TxTable, {
    rows: rows
  })));
}
Object.assign(window, {
  Transactions
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/web_app/Transactions.jsx", error: String((e && e.message) || e) }); }

__ds_ns.CoachCapsule = __ds_scope.CoachCapsule;

__ds_ns.CoachMessage = __ds_scope.CoachMessage;

__ds_ns.CoachSuggestion = __ds_scope.CoachSuggestion;

__ds_ns.Avatar = __ds_scope.Avatar;

__ds_ns.Badge = __ds_scope.Badge;

__ds_ns.Button = __ds_scope.Button;

__ds_ns.Icon = __ds_scope.Icon;

__ds_ns.OLMENTA_ICON_NAMES = __ds_scope.OLMENTA_ICON_NAMES;

__ds_ns.IconButton = __ds_scope.IconButton;

__ds_ns.SegmentedControl = __ds_scope.SegmentedControl;

__ds_ns.Switch = __ds_scope.Switch;

__ds_ns.BalanceCard = __ds_scope.BalanceCard;

__ds_ns.BudgetBar = __ds_scope.BudgetBar;

__ds_ns.IconChip = __ds_scope.IconChip;

__ds_ns.StatCard = __ds_scope.StatCard;

__ds_ns.TransactionRow = __ds_scope.TransactionRow;

__ds_ns.Input = __ds_scope.Input;

__ds_ns.SearchInput = __ds_scope.SearchInput;

})();
