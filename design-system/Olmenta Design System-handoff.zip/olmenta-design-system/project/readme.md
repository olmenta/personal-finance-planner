# Olmenta — Design System

Olmenta is a **modern AI personal finance coach**, available as a **mobile app (iOS)** and a **web app**. Where most budgeting apps just *show* you numbers, Olmenta *talks* to you about them: a proactive AI coach watches your money, flags drift, and helps you hit goals. The product feel is **calm, premium fintech with a warm, human voice** — trustworthy enough to hold your money, friendly enough to coach you daily.

The name carries the brand: **"menta" = mint**. Olmenta pairs a confident **violet** (intelligence, the primary action) with a fresh **mint** (the coach, growth, money in motion). Violet anchors; mint speaks.

---

## Sources

This system was derived from materials the user provided. Store these for reference (the reader may not have access):

- `uploads/paylix-design-system.html` — a reference design-system page for *Paylix*, a sibling budgeting-app concept. Olmenta inherits its strong fintech foundations (violet core, generous radii, soft white cards, tabular money figures, the dark "insight" capsule) and **evolves them into Olmenta's own identity** (added mint accent, renamed token system, AI-coach component family, web surface).
- `uploads/Shot 2026-06-10 at 16.41.06.png` — Paylix app screenshots (Home + Report) used as visual reference for the money surfaces, balance hero, donut report, bottom nav, and the dark "Your insight is ready" capsule.

There was **no codebase or Figma file** attached — the component recreations here are built from the reference design language, not imported from production source. See **Caveats** at the bottom.

---

## Brand fundamentals

| | |
|---|---|
| **Name** | Olmenta |
| **Category** | AI personal finance coach (budgeting + goals + proactive insights) |
| **Surfaces** | iOS mobile app · responsive web app |
| **Personality** | Calm, smart, encouraging — a coach, not a bank |
| **Primary color** | Violet `#7C5CFC` |
| **Accent color** | Mint `#16C79A` |
| **Typeface** | Inter (UI + display) · Geist Mono (metadata) |
| **Signature moment** | The mint-leaf mark with sparkles · the dark, sparkle-led **Coach** capsule + conversational coach |

---

## CONTENT FUNDAMENTALS — how Olmenta writes

**Voice: a sharp, supportive coach.** Olmenta speaks *to you* in second person ("you're spending 18% more on dining"), and refers to itself as "I" only in the coach conversation ("I'll check in mid-month"). It is direct and specific, never preachy or alarmist. It celebrates progress and frames problems as solvable.

- **Person & address:** "you / your" for the user; the coach uses "I" sparingly and warmly. Avoid corporate "we."
- **Casing:** **Sentence case** everywhere — buttons, headings, titles. UPPERCASE is reserved for tiny eyebrow labels/captions (e.g. `FOR THE PERIOD`, `THIS MONTH`).
- **Tone:** confident and concrete. Prefer real numbers and timeframes ("$784 than last week", "on track for Japan") over vague encouragement.
- **Action labels are verbs that say exactly what happens** and stay identical across the flow: *Add transaction*, *Ask the coach*, *Set a $300 cap*, *View details*. Never "Submit" / "OK".
- **Money is always specific:** "$87,457.85", "+$784 than last week", "$300 / month". Tabular figures, real signs.
- **Coach copy is short, human, and one idea at a time.** A capsule is a single insight ("You're spending 18% more on dining this month → See why"). Chat replies are 1–2 sentences.
- **Emoji:** *very* sparing — only inside the coach's conversational voice, at most one, to add warmth (a single 🎌 when celebrating a goal). Never in UI chrome, buttons, labels, or marketing headings. The system's "icons" are line glyphs, not emoji.
- **Empty states have direction**, never apology: "No transactions yet — add your first to start coaching." invites action.

**Example microcopy**
- Balance: `Current balance` · `↑ $784 than last week`
- Coach capsule: `You're spending 18% more on dining this month` · CTA `See why`
- Coach chat: *"Want me to set a $300 cap and nudge you when you're close?"*
- Buttons: `Add transaction` · `Ask the coach` · `Set the cap` · `View report`
- Eyebrows: `FOR THE PERIOD` · `YOUR MONEY` · `THIS MONTH`

---

## VISUAL FOUNDATIONS

**Color & vibe.** Two brand colors, used with discipline. **Violet** is the signature — it appears on the primary action (FAB, primary buttons), the balance gradient, and the first chart segment. **Mint** is the coach/growth accent — the sparkle, positive coaching actions, and growth metrics. Everything else lives in **white surfaces on a faintly violet-tinted background** (`#F5F3FB`), held together by **violet-tinted neutrals** (the ink is `#14131A`, slightly warm-cool toward violet, not pure black). Semantic color is reserved strictly for **money direction**: income green `#18BE7C`, expense red `#F2503C` — never decorative. *Spend the violet in one place; if everything is violet, nothing is.*

**Typography.** One family, **Inter**, across all UI and headings — clean, neutral, highly legible at every size. **Money and big numbers** use weight 800, tight negative tracking, and **tabular figures**es** so columns of amounts align cleanly. Body copy rests at 400–500. **Geist Mono** is a supporting voice for small metadata — account numbers, timestamps, tickers. Headings carry slight negative letter-spacing; body is neutral.

**Spacing & layout.** Base-4 spacing scale. Mobile is a single 390px column with comfortable 20–24px gutters; web uses a 264px sidebar + fluid content up to ~1200px. Hit targets never below 44px. Fixed elements: the mobile **bottom nav** (with a centered violet FAB) is pinned; the web **sidebar** is sticky.

**Corner radii — generous and friendly.** This is core to Olmenta's warmth. Inputs 10px, icon chips/list items 14px, block buttons 18px, **cards 24px**, sheets & hero cards 30px, the phone screen and large panels 36px, and **full pills (999px)** for buttons, badges, FAB, avatars, and the coach capsule. Almost nothing has a sharp corner.

**Cards.** White (`#FFFFFF`), 24px radius, a 1px hairline border (`#E7E4EE`) **and** a soft shadow — both, lightly. They sit on the tinted background with clear separation but no heavy elevation. No colored left-border accents; no gradient card fills (except the two intentional hero gradients).

**Backgrounds.** Solid, calm, violet-tinted light surfaces — **no photographic backgrounds, no textures, no noise**. The only gradients in the system are deliberate and rare: the **violet balance hero** and the **dark coach capsule/avatar**. Marketing/web hero may use a soft violet wash. No mesh gradients, no bluish-purple AI-slop gradients.

**Elevation / shadows.** Contained and soft, tinted toward violet (`rgba(40,30,80,…)`). A five-step scale from `--shadow-xs` (list cards) to `--shadow-xl` (modals). Two **tinted glow** shadows are special and rare: `--shadow-fab` (violet glow, **FAB only**) and `--shadow-coach` (dark, the coach capsule). Inputs use a subtle inner well.

**Borders.** 1px hairlines in `#E7E4EE`; 1.5px for input borders and focus. Focus is a 3px violet ring (`--focus-ring`), never a browser outline.

**Transparency & blur.** Used lightly: the balance hero's delta pill and the coach capsule's sparkle tile use translucent white + a small backdrop blur. Overlays dim the screen at `rgba(20,19,26,.46)`. No frosted-glass everywhere — it's an accent.

**Motion.** Quick and physical, never showy. Default UI easing `cubic-bezier(.2,.8,.2,1)`; **press** uses a slight spring (`--ease-spring`) and a 0.97 scale-down. Durations 120–280ms. Bars and meters animate their fill on mount; content fades/rises in. Honor `prefers-reduced-motion`. No infinite decorative loops.

**Hover / press states.**
- *Hover (web):* primary/accent buttons darken one step (500 → 600); ghost surfaces fill with a faint violet (`--violet-50`) and the border tints violet; suggestion chips do the same.
- *Press (all):* a brief spring scale-down (buttons 0.97, icon buttons 0.94). No color flash beyond the hover step.
- *Disabled:* 45% opacity, no shadow, `not-allowed`.

**Imagery vibe.** When real imagery appears (avatars, marketing), keep it **warm, bright, optimistic, true-color** — no heavy filters, no black & white, no grain. Avatars are circular, often with a mint or violet status ring.

---

## ICONOGRAPHY

Olmenta's icon language is **Lucide** — 2px stroke, round caps/joins, 24px grid, single-color (inherits `currentColor`). This replaces the emoji icon-chips used in the original Paylix reference, which were placeholders.

- **Delivery:** icons are bundled as inline-SVG path data inside the `Icon` component (`components/core/Icon.jsx`) — copied from Lucide (ISC license). This keeps rendering self-contained, recolorable, and crisp; no runtime CDN dependency. Use `<Icon name="…" />` or the `OLMENTA_ICON_NAMES` list to see what's available (~48 glyphs covering finance, navigation, and UI).
- **The sparkle (`sparkles`) is reserved for the AI coach** — it appears in the coach capsule, the coach avatar, and the "Ask the coach" action. Don't use it decoratively elsewhere.
- **Category chips** use a tinted square (`IconChip`) holding a full-color Lucide glyph; the tint follows the *category*, not the amount.
- **Emoji** are **not** part of the icon system — only an occasional single emoji inside the coach's conversational copy. **Unicode glyphs** (↑ ↓ ↳ ›) are used lightly inline in copy (deltas, sub-lines), not as primary icons.
- If you need a glyph not in the set, add its Lucide path to `OL_ICONS` in `Icon.jsx` (copy from lucide.dev) — keep the same stroke style. Do not hand-draw or mix in another icon family.

---

## File index (manifest)

Root
- **`styles.css`** — the single entry point consumers link. `@import`s only.
- **`readme.md`** — this guide.
- **`SKILL.md`** — Agent-Skills-compatible front-matter wrapper.
- `_ds_bundle.js`, `_ds_manifest.json`, `_adherence.oxlintrc.json` — **generated**, do not edit.

`tokens/` — global CSS, reached from `styles.css`
- `fonts.css` (Google Fonts import) · `colors.css` · `typography.css` · `spacing.css` (spacing/radii/shadows/motion/z) · `base.css` (reset + element defaults).

`components/` — reusable React primitives (namespace `window.OlmentaDesignSystem_4bdf9c`)
- `core/` — **Icon, Button, IconButton, Badge, SegmentedControl, Avatar, Switch**
- `forms/` — **Input, SearchInput**
- `finance/` — **IconChip, BalanceCard, StatCard, TransactionRow, BudgetBar**
- `coach/` — **CoachCapsule, CoachMessage, CoachSuggestion** (the AI family)
- Each directory has a `*.card.html` thumbnail tagged `@dsCard group="Components"`.

`guidelines/` — foundation specimen cards (Type, Colors, Spacing, Brand) shown in the Design System tab.

`ui_kits/` — full-screen product recreations
- `mobile_app/` — iOS app: Home, Coach chat, Report
- `web_app/` — web dashboard with sidebar + coach panel

`assets/` — the Olmenta logo: `olmenta-mark.svg` (icon mark, used across the kits), `olmenta-logo-square.svg` (app icon), `olmenta-logo-landscape.svg` (horizontal lockup). The mark is a **green mint leaf** (veins cut in ink) with two mint-green sparkles, on an ink squircle — "menta" = mint. The sparkle ties to the AI coach motif.

---

## Using this system

Consumers link `styles.css` and read components from `window.OlmentaDesignSystem_4bdf9c`. In a `@dsCard` HTML, load `../../_ds_bundle.js` and destructure:

```js
const { Button, BalanceCard, CoachCapsule } = window.OlmentaDesignSystem_4bdf9c;
```

**Design principles**
1. **Spend the violet in one place.** Action + balance. The rest is white and gray.
2. **Money drives color.** Green in, red out — never decoration.
3. **The coach is the difference.** Lead with the sparkle, keep insights short and specific.
4. **Tabular figures, always.** Amounts align.
5. **Friendly corners, calm surfaces.** Generous radii, soft shadows, no clutter.
6. **Verbs that say what happens.** And keep the label the same across the flow.

---

## Caveats
- **No production codebase or Figma** was provided, so components are faithful *recreations* of the reference design language, not 1:1 imports. Names/props are Olmenta's own.
- **Fonts** (Inter, Geist Mono) load from **Google Fonts CDN** rather than self-hosted binaries — the sandbox can't fetch font files to vendor them. For offline/production, self-host the woff2 files and add `@font-face` rules under `tokens/`. Olmenta uses **Inter** for its UI/display type (matching the original Paylix reference).
- **Icons** are Lucide (copied path data), substituting the original's emoji chips. If a different icon set is mandated, swap `OL_ICONS`.
